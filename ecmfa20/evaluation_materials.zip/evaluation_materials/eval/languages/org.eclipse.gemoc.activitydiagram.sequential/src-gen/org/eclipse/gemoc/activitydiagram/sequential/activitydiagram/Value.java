/**
 */
package org.eclipse.gemoc.activitydiagram.sequential.activitydiagram;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Value</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ActivitydiagramPackage#getValue()
 * @model
 * @generated
 */
public interface Value extends EObject {
} // Value
