/**
 */
package org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.impl;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ActivityFinalNode;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ActivitydiagramPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Activity Final Node</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class ActivityFinalNodeImpl extends FinalNodeImpl implements ActivityFinalNode {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ActivityFinalNodeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ActivitydiagramPackage.Literals.ACTIVITY_FINAL_NODE;
	}

} //ActivityFinalNodeImpl
