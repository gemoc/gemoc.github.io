/**
 */
package org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.impl;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ActivitydiagramPackage;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.IntegerVariable;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Integer Variable</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class IntegerVariableImpl extends VariableImpl implements IntegerVariable {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected IntegerVariableImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ActivitydiagramPackage.Literals.INTEGER_VARIABLE;
	}

} //IntegerVariableImpl
