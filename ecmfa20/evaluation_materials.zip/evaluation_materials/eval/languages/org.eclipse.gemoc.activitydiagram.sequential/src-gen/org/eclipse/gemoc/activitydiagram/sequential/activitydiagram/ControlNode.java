/**
 */
package org.eclipse.gemoc.activitydiagram.sequential.activitydiagram;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Control Node</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ActivitydiagramPackage#getControlNode()
 * @model abstract="true"
 * @generated
 */
public interface ControlNode extends ActivityNode {
} // ControlNode
