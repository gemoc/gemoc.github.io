/**
 */
package org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.impl;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ActivitydiagramPackage;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ControlToken;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Control Token</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class ControlTokenImpl extends TokenImpl implements ControlToken {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ControlTokenImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ActivitydiagramPackage.Literals.CONTROL_TOKEN;
	}

} //ControlTokenImpl
