package org.tetrabox.minijava.xminijava.aspects;

import java.util.Map;
import org.tetrabox.minijava.xminijava.aspects.ModuloAspectModuloAspectProperties;
import org.tetrabox.minijava.xminijava.miniJava.Modulo;

@SuppressWarnings("all")
public class ModuloAspectModuloAspectContext {
  public final static ModuloAspectModuloAspectContext INSTANCE = new ModuloAspectModuloAspectContext();
  
  public static ModuloAspectModuloAspectProperties getSelf(final Modulo _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new org.tetrabox.minijava.xminijava.aspects.ModuloAspectModuloAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<Modulo, ModuloAspectModuloAspectProperties> map = new java.util.WeakHashMap<org.tetrabox.minijava.xminijava.miniJava.Modulo, org.tetrabox.minijava.xminijava.aspects.ModuloAspectModuloAspectProperties>();
  
  public Map<Modulo, ModuloAspectModuloAspectProperties> getMap() {
    return map;
  }
}
