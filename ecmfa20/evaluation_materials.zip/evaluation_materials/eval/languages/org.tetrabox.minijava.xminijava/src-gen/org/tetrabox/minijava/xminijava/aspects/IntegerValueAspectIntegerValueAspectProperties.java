package org.tetrabox.minijava.xminijava.aspects;

@SuppressWarnings("all")
public class IntegerValueAspectIntegerValueAspectProperties {
}
