package org.tetrabox.minijava.xminijava.aspects;

import java.util.HashMap;
import java.util.Map;
import org.tetrabox.minijava.xminijava.miniJava.Method;

@SuppressWarnings("all")
public class MethodAspectMethodAspectProperties {
  public Map<org.tetrabox.minijava.xminijava.miniJava.Class, Method> cache = new HashMap<org.tetrabox.minijava.xminijava.miniJava.Class, Method>();
}
