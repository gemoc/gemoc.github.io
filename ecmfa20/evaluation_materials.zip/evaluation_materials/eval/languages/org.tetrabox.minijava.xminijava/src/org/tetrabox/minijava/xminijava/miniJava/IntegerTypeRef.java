/**
 */
package org.tetrabox.minijava.xminijava.miniJava;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Integer Type Ref</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.tetrabox.minijava.xminijava.miniJava.MiniJavaPackage#getIntegerTypeRef()
 * @model
 * @generated
 */
public interface IntegerTypeRef extends SingleTypeRef {
} // IntegerTypeRef
