/**
 */
package org.tetrabox.minijava.xminijava.miniJava.impl;

import org.eclipse.emf.ecore.EClass;

import org.tetrabox.minijava.xminijava.miniJava.MiniJavaPackage;
import org.tetrabox.minijava.xminijava.miniJava.SingleTypeRef;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Single Type Ref</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class SingleTypeRefImpl extends TypeRefImpl implements SingleTypeRef {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SingleTypeRefImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MiniJavaPackage.Literals.SINGLE_TYPE_REF;
	}

} //SingleTypeRefImpl
