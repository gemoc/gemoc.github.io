/**
 */
package org.tetrabox.minijava.xminijava.miniJava;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Assignee</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.tetrabox.minijava.xminijava.miniJava.MiniJavaPackage#getAssignee()
 * @model
 * @generated
 */
public interface Assignee extends EObject {
} // Assignee
