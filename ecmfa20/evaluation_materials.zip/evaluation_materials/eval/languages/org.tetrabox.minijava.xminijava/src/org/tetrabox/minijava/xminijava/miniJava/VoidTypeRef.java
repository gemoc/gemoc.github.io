/**
 */
package org.tetrabox.minijava.xminijava.miniJava;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Void Type Ref</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.tetrabox.minijava.xminijava.miniJava.MiniJavaPackage#getVoidTypeRef()
 * @model
 * @generated
 */
public interface VoidTypeRef extends SingleTypeRef {
} // VoidTypeRef
