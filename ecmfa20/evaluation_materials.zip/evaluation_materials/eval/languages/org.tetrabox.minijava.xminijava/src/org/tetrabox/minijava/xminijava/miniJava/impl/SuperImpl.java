/**
 */
package org.tetrabox.minijava.xminijava.miniJava.impl;

import org.eclipse.emf.ecore.EClass;

import org.tetrabox.minijava.xminijava.miniJava.MiniJavaPackage;
import org.tetrabox.minijava.xminijava.miniJava.Super;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Super</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class SuperImpl extends ExpressionImpl implements Super {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SuperImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MiniJavaPackage.Literals.SUPER;
	}

} //SuperImpl
