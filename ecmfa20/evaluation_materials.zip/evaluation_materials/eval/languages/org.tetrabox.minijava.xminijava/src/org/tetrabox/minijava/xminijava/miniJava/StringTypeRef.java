/**
 */
package org.tetrabox.minijava.xminijava.miniJava;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>String Type Ref</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.tetrabox.minijava.xminijava.miniJava.MiniJavaPackage#getStringTypeRef()
 * @model
 * @generated
 */
public interface StringTypeRef extends SingleTypeRef {
} // StringTypeRef
