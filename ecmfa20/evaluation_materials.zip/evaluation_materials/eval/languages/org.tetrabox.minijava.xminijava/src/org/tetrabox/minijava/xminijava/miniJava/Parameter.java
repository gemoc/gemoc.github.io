/**
 */
package org.tetrabox.minijava.xminijava.miniJava;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Parameter</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.tetrabox.minijava.xminijava.miniJava.MiniJavaPackage#getParameter()
 * @model
 * @generated
 */
public interface Parameter extends Symbol {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	boolean compare(Parameter other);

} // Parameter
