/**
 */
package org.tetrabox.minijava.xminijava.miniJava;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Single Type Ref</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.tetrabox.minijava.xminijava.miniJava.MiniJavaPackage#getSingleTypeRef()
 * @model
 * @generated
 */
public interface SingleTypeRef extends TypeRef {
} // SingleTypeRef
