/**
 */
package org.tetrabox.minijava.xminijava.miniJava;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Symbol</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.tetrabox.minijava.xminijava.miniJava.MiniJavaPackage#getSymbol()
 * @model
 * @generated
 */
public interface Symbol extends TypedDeclaration {
} // Symbol
