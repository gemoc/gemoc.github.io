package org.eclipse.gemoc.activitydiagram.sequential.k3dsa;

import java.util.Map;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ForkedToken;
import org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ForkedTokenAspectForkedTokenAspectProperties;

@SuppressWarnings("all")
public class ForkedTokenAspectForkedTokenAspectContext {
  public final static ForkedTokenAspectForkedTokenAspectContext INSTANCE = new ForkedTokenAspectForkedTokenAspectContext();
  
  public static ForkedTokenAspectForkedTokenAspectProperties getSelf(final ForkedToken _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ForkedTokenAspectForkedTokenAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<ForkedToken, ForkedTokenAspectForkedTokenAspectProperties> map = new java.util.WeakHashMap<org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ForkedToken, org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ForkedTokenAspectForkedTokenAspectProperties>();
  
  public Map<ForkedToken, ForkedTokenAspectForkedTokenAspectProperties> getMap() {
    return map;
  }
}
