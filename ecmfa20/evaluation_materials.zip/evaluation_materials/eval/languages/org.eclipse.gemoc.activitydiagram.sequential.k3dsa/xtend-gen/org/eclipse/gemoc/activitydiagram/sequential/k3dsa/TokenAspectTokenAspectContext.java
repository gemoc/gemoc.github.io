package org.eclipse.gemoc.activitydiagram.sequential.k3dsa;

import java.util.Map;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Token;
import org.eclipse.gemoc.activitydiagram.sequential.k3dsa.TokenAspectTokenAspectProperties;

@SuppressWarnings("all")
public class TokenAspectTokenAspectContext {
  public final static TokenAspectTokenAspectContext INSTANCE = new TokenAspectTokenAspectContext();
  
  public static TokenAspectTokenAspectProperties getSelf(final Token _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new org.eclipse.gemoc.activitydiagram.sequential.k3dsa.TokenAspectTokenAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<Token, TokenAspectTokenAspectProperties> map = new java.util.WeakHashMap<org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Token, org.eclipse.gemoc.activitydiagram.sequential.k3dsa.TokenAspectTokenAspectProperties>();
  
  public Map<Token, TokenAspectTokenAspectProperties> getMap() {
    return map;
  }
}
