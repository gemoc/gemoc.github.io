package org.eclipse.gemoc.activitydiagram.sequential.k3dsa;

import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Token;
import org.eclipse.gemoc.activitydiagram.sequential.k3dsa.TokenAspectTokenAspectProperties;

@Aspect(className = Token.class)
@SuppressWarnings("all")
public class TokenAspect {
  public static boolean isWithdrawn(final Token _self) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.TokenAspectTokenAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.TokenAspectTokenAspectContext.getSelf(_self);
    Object result = null;
    // #DispatchPointCut_before# boolean isWithdrawn()
    if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Token){
    	result = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.TokenAspect._privk3_isWithdrawn(_self_, (org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Token)_self);
    };
    return (boolean)result;
  }
  
  protected static boolean _privk3_isWithdrawn(final TokenAspectTokenAspectProperties _self_, final Token _self) {
    EObject _eContainer = _self.eContainer();
    return (_eContainer == null);
  }
}
