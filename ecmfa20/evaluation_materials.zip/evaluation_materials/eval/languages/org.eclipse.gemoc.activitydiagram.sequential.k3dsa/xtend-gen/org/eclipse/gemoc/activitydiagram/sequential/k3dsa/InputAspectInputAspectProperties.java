package org.eclipse.gemoc.activitydiagram.sequential.k3dsa;

import org.eclipse.emf.common.util.EList;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.InputValue;

@SuppressWarnings("all")
public class InputAspectInputAspectProperties {
  public EList<InputValue> inputValues;
}
