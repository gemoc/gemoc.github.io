package org.eclipse.gemoc.activitydiagram.sequential.k3dsa;

import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Value;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Variable;

@SuppressWarnings("all")
public class InputValueAspectInputValueAspectProperties {
  public Variable variable;
  
  public Value value;
}
