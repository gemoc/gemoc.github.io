package org.eclipse.gemoc.activitydiagram.sequential.k3dsa;

import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import org.eclipse.emf.common.util.EList;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ActivityNode;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Trace;
import org.eclipse.gemoc.activitydiagram.sequential.k3dsa.TraceAspectTraceAspectProperties;

@Aspect(className = Trace.class)
@SuppressWarnings("all")
public class TraceAspect {
  public static EList<ActivityNode> executedNodes(final Trace _self) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.TraceAspectTraceAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.TraceAspectTraceAspectContext.getSelf(_self);
    Object result = null;
    // #DispatchPointCut_before# EList<ActivityNode> executedNodes()
    if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Trace){
    	result = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.TraceAspect._privk3_executedNodes(_self_, (org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Trace)_self);
    };
    return (org.eclipse.emf.common.util.EList<org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ActivityNode>)result;
  }
  
  public static void executedNodes(final Trace _self, final EList<ActivityNode> executedNodes) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.TraceAspectTraceAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.TraceAspectTraceAspectContext.getSelf(_self);
    // #DispatchPointCut_before# void executedNodes(EList<ActivityNode>)
    if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Trace){
    	org.eclipse.gemoc.activitydiagram.sequential.k3dsa.TraceAspect._privk3_executedNodes(_self_, (org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Trace)_self,executedNodes);
    };
  }
  
  protected static EList<ActivityNode> _privk3_executedNodes(final TraceAspectTraceAspectProperties _self_, final Trace _self) {
    try {
    	for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    		if (m.getName().equals("getExecutedNodes") &&
    			m.getParameterTypes().length == 0) {
    				Object ret = m.invoke(_self);
    				if (ret != null) {
    					return (org.eclipse.emf.common.util.EList) ret;
    				} else {
    					return null;
    				}
    		}
    	}
    } catch (Exception e) {
    	// Chut !
    }
    return _self_.executedNodes;
  }
  
  protected static void _privk3_executedNodes(final TraceAspectTraceAspectProperties _self_, final Trace _self, final EList<ActivityNode> executedNodes) {
    boolean setterCalled = false;
    try {
    	for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    		if (m.getName().equals("setExecutedNodes")
    				&& m.getParameterTypes().length == 1) {
    			m.invoke(_self, executedNodes);
    			setterCalled = true;
    		}
    	}
    } catch (Exception e) {
    	// Chut !
    }
    if (!setterCalled) {
    	_self_.executedNodes = executedNodes;
    }
  }
}
