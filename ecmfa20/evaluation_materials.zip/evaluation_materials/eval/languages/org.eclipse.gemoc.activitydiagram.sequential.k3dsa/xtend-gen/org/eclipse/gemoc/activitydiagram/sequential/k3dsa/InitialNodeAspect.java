package org.eclipse.gemoc.activitydiagram.sequential.k3dsa;

import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import fr.inria.diverse.k3.al.annotationprocessor.OverrideAspectMethod;
import org.eclipse.emf.common.util.BasicEList;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ActivitydiagramFactory;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ControlToken;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.InitialNode;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Token;
import org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspect;
import org.eclipse.gemoc.activitydiagram.sequential.k3dsa.InitialNodeAspectInitialNodeAspectProperties;

@Aspect(className = InitialNode.class)
@SuppressWarnings("all")
public class InitialNodeAspect extends ActivityNodeAspect {
  @OverrideAspectMethod
  public static void execute(final InitialNode _self) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.InitialNodeAspectInitialNodeAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.InitialNodeAspectInitialNodeAspectContext.getSelf(_self);
    // #DispatchPointCut_before# void execute()
    if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.InitialNode){
    	org.eclipse.gemoc.activitydiagram.sequential.k3dsa.InitialNodeAspect._privk3_execute(_self_, (org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.InitialNode)_self);
    };
  }
  
  @OverrideAspectMethod
  public static boolean hasOffers(final InitialNode _self) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.InitialNodeAspectInitialNodeAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.InitialNodeAspectInitialNodeAspectContext.getSelf(_self);
    Object result = null;
    // #DispatchPointCut_before# boolean hasOffers()
    if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.InitialNode){
    	result = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.InitialNodeAspect._privk3_hasOffers(_self_, (org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.InitialNode)_self);
    };
    return (boolean)result;
  }
  
  private static void super_execute(final InitialNode _self) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspectActivityNodeAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspectActivityNodeAspectContext.getSelf(_self);
     org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspect._privk3_execute(_self_, _self);
  }
  
  protected static void _privk3_execute(final InitialNodeAspectInitialNodeAspectProperties _self_, final InitialNode _self) {
    ControlToken r = ActivitydiagramFactory.eINSTANCE.createControlToken();
    _self.getHeldTokens().add(r);
    BasicEList<Token> list = new BasicEList<Token>();
    list.add(r);
    ActivityNodeAspect.sendOffers(_self, list);
  }
  
  private static boolean super_hasOffers(final InitialNode _self) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspectActivityNodeAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspectActivityNodeAspectContext.getSelf(_self);
    return  org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspect._privk3_hasOffers(_self_, _self);
  }
  
  protected static boolean _privk3_hasOffers(final InitialNodeAspectInitialNodeAspectProperties _self_, final InitialNode _self) {
    return false;
  }
}
