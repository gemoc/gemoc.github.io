package org.eclipse.gemoc.activitydiagram.sequential.k3dsa;

import java.util.Map;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.InputValue;
import org.eclipse.gemoc.activitydiagram.sequential.k3dsa.InputValueAspectInputValueAspectProperties;

@SuppressWarnings("all")
public class InputValueAspectInputValueAspectContext {
  public final static InputValueAspectInputValueAspectContext INSTANCE = new InputValueAspectInputValueAspectContext();
  
  public static InputValueAspectInputValueAspectProperties getSelf(final InputValue _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new org.eclipse.gemoc.activitydiagram.sequential.k3dsa.InputValueAspectInputValueAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<InputValue, InputValueAspectInputValueAspectProperties> map = new java.util.WeakHashMap<org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.InputValue, org.eclipse.gemoc.activitydiagram.sequential.k3dsa.InputValueAspectInputValueAspectProperties>();
  
  public Map<InputValue, InputValueAspectInputValueAspectProperties> getMap() {
    return map;
  }
}
