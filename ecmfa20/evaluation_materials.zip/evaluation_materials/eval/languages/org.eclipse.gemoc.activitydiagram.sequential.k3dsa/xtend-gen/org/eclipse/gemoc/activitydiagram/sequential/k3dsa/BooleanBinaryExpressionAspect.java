package org.eclipse.gemoc.activitydiagram.sequential.k3dsa;

import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import fr.inria.diverse.k3.al.annotationprocessor.OverrideAspectMethod;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.BooleanBinaryExpression;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.BooleanBinaryOperator;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.BooleanValue;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Value;
import org.eclipse.gemoc.activitydiagram.sequential.k3dsa.BooleanBinaryExpressionAspectBooleanBinaryExpressionAspectProperties;
import org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ExpressionAspect;

@Aspect(className = BooleanBinaryExpression.class)
@SuppressWarnings("all")
public class BooleanBinaryExpressionAspect extends ExpressionAspect {
  @OverrideAspectMethod
  public static void execute(final BooleanBinaryExpression _self) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.BooleanBinaryExpressionAspectBooleanBinaryExpressionAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.BooleanBinaryExpressionAspectBooleanBinaryExpressionAspectContext.getSelf(_self);
    // #DispatchPointCut_before# void execute()
    if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.BooleanBinaryExpression){
    	org.eclipse.gemoc.activitydiagram.sequential.k3dsa.BooleanBinaryExpressionAspect._privk3_execute(_self_, (org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.BooleanBinaryExpression)_self);
    };
  }
  
  private static void super_execute(final BooleanBinaryExpression _self) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ExpressionAspectExpressionAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ExpressionAspectExpressionAspectContext.getSelf(_self);
     org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ExpressionAspect._privk3_execute(_self_, _self);
  }
  
  protected static void _privk3_execute(final BooleanBinaryExpressionAspectBooleanBinaryExpressionAspectProperties _self_, final BooleanBinaryExpression _self) {
    int _value = _self.getOperator().getValue();
    boolean _equals = (_value == BooleanBinaryOperator.AND_VALUE);
    if (_equals) {
      Value _currentValue = _self.getAssignee().getCurrentValue();
      ((BooleanValue) _currentValue).setValue((((BooleanValue) _self.getOperand1().getCurrentValue()).isValue() && 
        ((BooleanValue) _self.getOperand2().getCurrentValue()).isValue()));
    } else {
      int _value_1 = _self.getOperator().getValue();
      boolean _equals_1 = (_value_1 == BooleanBinaryOperator.OR_VALUE);
      if (_equals_1) {
        Value _currentValue_1 = _self.getAssignee().getCurrentValue();
        ((BooleanValue) _currentValue_1).setValue((((BooleanValue) _self.getOperand1().getCurrentValue()).isValue() || 
          ((BooleanValue) _self.getOperand2().getCurrentValue()).isValue()));
      }
    }
  }
}
