package org.eclipse.gemoc.activitydiagram.sequential.k3dsa;

import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import fr.inria.diverse.k3.al.annotationprocessor.OverrideAspectMethod;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.IntegerCalculationExpression;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.IntegerCalculationOperator;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.IntegerValue;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Value;
import org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ExpressionAspect;
import org.eclipse.gemoc.activitydiagram.sequential.k3dsa.IntegerCalculationExpressionAspectIntegerCalculationExpressionAspectProperties;

@Aspect(className = IntegerCalculationExpression.class)
@SuppressWarnings("all")
public class IntegerCalculationExpressionAspect extends ExpressionAspect {
  @OverrideAspectMethod
  public static void execute(final IntegerCalculationExpression _self) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.IntegerCalculationExpressionAspectIntegerCalculationExpressionAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.IntegerCalculationExpressionAspectIntegerCalculationExpressionAspectContext.getSelf(_self);
    // #DispatchPointCut_before# void execute()
    if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.IntegerCalculationExpression){
    	org.eclipse.gemoc.activitydiagram.sequential.k3dsa.IntegerCalculationExpressionAspect._privk3_execute(_self_, (org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.IntegerCalculationExpression)_self);
    };
  }
  
  private static void super_execute(final IntegerCalculationExpression _self) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ExpressionAspectExpressionAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ExpressionAspectExpressionAspectContext.getSelf(_self);
     org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ExpressionAspect._privk3_execute(_self_, _self);
  }
  
  protected static void _privk3_execute(final IntegerCalculationExpressionAspectIntegerCalculationExpressionAspectProperties _self_, final IntegerCalculationExpression _self) {
    int _value = _self.getOperator().getValue();
    boolean _equals = (_value == IntegerCalculationOperator.ADD_VALUE);
    if (_equals) {
      Value _currentValue = _self.getAssignee().getCurrentValue();
      Value _currentValue_1 = _self.getOperand1().getCurrentValue();
      int _value_1 = ((IntegerValue) _currentValue_1).getValue();
      Value _currentValue_2 = _self.getOperand2().getCurrentValue();
      int _value_2 = ((IntegerValue) _currentValue_2).getValue();
      int _plus = (_value_1 + _value_2);
      ((IntegerValue) _currentValue).setValue(_plus);
    } else {
      int _value_3 = _self.getOperator().getValue();
      boolean _equals_1 = (_value_3 == IntegerCalculationOperator.SUBRACT_VALUE);
      if (_equals_1) {
        Value _currentValue_3 = _self.getAssignee().getCurrentValue();
        Value _currentValue_4 = _self.getOperand1().getCurrentValue();
        int _value_4 = ((IntegerValue) _currentValue_4).getValue();
        Value _currentValue_5 = _self.getOperand2().getCurrentValue();
        int _value_5 = ((IntegerValue) _currentValue_5).getValue();
        int _minus = (_value_4 - _value_5);
        ((IntegerValue) _currentValue_3).setValue(_minus);
      } else {
        int _value_6 = _self.getOperator().getValue();
        boolean _equals_2 = (_value_6 == IntegerCalculationOperator.MULTIPLY_VALUE);
        if (_equals_2) {
          Value _currentValue_6 = _self.getAssignee().getCurrentValue();
          Value _currentValue_7 = _self.getOperand1().getCurrentValue();
          int _value_7 = ((IntegerValue) _currentValue_7).getValue();
          Value _currentValue_8 = _self.getOperand2().getCurrentValue();
          int _value_8 = ((IntegerValue) _currentValue_8).getValue();
          int _multiply = (_value_7 * _value_8);
          ((IntegerValue) _currentValue_6).setValue(_multiply);
        } else {
          int _value_9 = _self.getOperator().getValue();
          boolean _equals_3 = (_value_9 == IntegerCalculationOperator.DIVIDE_VALUE);
          if (_equals_3) {
            Value _currentValue_9 = _self.getAssignee().getCurrentValue();
            Value _currentValue_10 = _self.getOperand1().getCurrentValue();
            int _value_10 = ((IntegerValue) _currentValue_10).getValue();
            Value _currentValue_11 = _self.getOperand2().getCurrentValue();
            int _value_11 = ((IntegerValue) _currentValue_11).getValue();
            int _divide = (_value_10 / _value_11);
            ((IntegerValue) _currentValue_9).setValue(_divide);
          } else {
            int _value_12 = _self.getOperator().getValue();
            boolean _equals_4 = (_value_12 == IntegerCalculationOperator.MOD_VALUE);
            if (_equals_4) {
              Value _currentValue_12 = _self.getAssignee().getCurrentValue();
              Value _currentValue_13 = _self.getOperand1().getCurrentValue();
              int _value_13 = ((IntegerValue) _currentValue_13).getValue();
              Value _currentValue_14 = _self.getOperand2().getCurrentValue();
              int _value_14 = ((IntegerValue) _currentValue_14).getValue();
              int _modulo = (_value_13 % _value_14);
              ((IntegerValue) _currentValue_12).setValue(_modulo);
            }
          }
        }
      }
    }
  }
}
