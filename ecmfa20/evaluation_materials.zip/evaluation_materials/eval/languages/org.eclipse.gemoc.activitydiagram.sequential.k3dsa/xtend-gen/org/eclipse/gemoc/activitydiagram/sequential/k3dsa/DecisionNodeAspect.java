package org.eclipse.gemoc.activitydiagram.sequential.k3dsa;

import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import fr.inria.diverse.k3.al.annotationprocessor.OverrideAspectMethod;
import org.eclipse.emf.common.util.EList;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ActivityEdge;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.BooleanValue;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ControlFlow;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.DecisionNode;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Token;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Value;
import org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityEdgeAspect;
import org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspect;
import org.eclipse.gemoc.activitydiagram.sequential.k3dsa.DecisionNodeAspectDecisionNodeAspectProperties;

@Aspect(className = DecisionNode.class)
@SuppressWarnings("all")
public class DecisionNodeAspect extends ActivityNodeAspect {
  @OverrideAspectMethod
  public static void execute(final DecisionNode _self) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.DecisionNodeAspectDecisionNodeAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.DecisionNodeAspectDecisionNodeAspectContext.getSelf(_self);
    // #DispatchPointCut_before# void execute()
    if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.DecisionNode){
    	org.eclipse.gemoc.activitydiagram.sequential.k3dsa.DecisionNodeAspect._privk3_execute(_self_, (org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.DecisionNode)_self);
    };
  }
  
  @OverrideAspectMethod
  public static void sendOffers(final DecisionNode _self, final EList<Token> tokens) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.DecisionNodeAspectDecisionNodeAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.DecisionNodeAspectDecisionNodeAspectContext.getSelf(_self);
    // #DispatchPointCut_before# void sendOffers(EList<Token>)
    if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.DecisionNode){
    	org.eclipse.gemoc.activitydiagram.sequential.k3dsa.DecisionNodeAspect._privk3_sendOffers(_self_, (org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.DecisionNode)_self,tokens);
    };
  }
  
  private static void super_execute(final DecisionNode _self) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspectActivityNodeAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspectActivityNodeAspectContext.getSelf(_self);
     org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspect._privk3_execute(_self_, _self);
  }
  
  protected static void _privk3_execute(final DecisionNodeAspectDecisionNodeAspectProperties _self_, final DecisionNode _self) {
    DecisionNodeAspect.sendOffers(_self, ActivityNodeAspect.takeOfferdTokens(_self));
  }
  
  private static void super_sendOffers(final DecisionNode _self, final EList<Token> tokens) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspectActivityNodeAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspectActivityNodeAspectContext.getSelf(_self);
     org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspect._privk3_sendOffers(_self_, _self,tokens);
  }
  
  protected static void _privk3_sendOffers(final DecisionNodeAspectDecisionNodeAspectProperties _self_, final DecisionNode _self, final EList<Token> tokens) {
    EList<ActivityEdge> _outgoing = _self.getOutgoing();
    for (final ActivityEdge edge : _outgoing) {
      if (((edge instanceof ControlFlow) && (((ControlFlow) edge).getGuard() != null))) {
        Value _currentValue = ((ControlFlow) edge).getGuard().getCurrentValue();
        boolean _isValue = ((BooleanValue) _currentValue).isValue();
        if (_isValue) {
          ActivityEdgeAspect.sendOffer(edge, tokens);
        }
      }
    }
  }
}
