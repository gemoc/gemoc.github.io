package org.eclipse.gemoc.activitydiagram.sequential.k3dsa;

@SuppressWarnings("all")
public class BooleanUnaryExpressionAspectBooleanUnaryExpressionAspectProperties {
}
