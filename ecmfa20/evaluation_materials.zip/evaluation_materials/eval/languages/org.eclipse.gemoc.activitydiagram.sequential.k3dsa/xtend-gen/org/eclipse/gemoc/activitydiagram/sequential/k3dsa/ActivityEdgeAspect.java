package org.eclipse.gemoc.activitydiagram.sequential.k3dsa;

import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import fr.inria.diverse.k3.al.annotationprocessor.Containment;
import java.util.function.Consumer;
import org.eclipse.emf.common.util.BasicEList;
import org.eclipse.emf.common.util.EList;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ActivityEdge;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ActivitydiagramFactory;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Offer;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Token;
import org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityEdgeAspectActivityEdgeAspectProperties;
import org.eclipse.gemoc.activitydiagram.sequential.k3dsa.NamedElementAspect;
import org.eclipse.gemoc.activitydiagram.sequential.k3dsa.OfferAspect;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.IterableExtensions;

@Aspect(className = ActivityEdge.class)
@SuppressWarnings("all")
public class ActivityEdgeAspect extends NamedElementAspect {
  public static void sendOffer(final ActivityEdge _self, final EList<Token> tokens) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityEdgeAspectActivityEdgeAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityEdgeAspectActivityEdgeAspectContext.getSelf(_self);
    // #DispatchPointCut_before# void sendOffer(EList<Token>)
    if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ActivityEdge){
    	org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityEdgeAspect._privk3_sendOffer(_self_, (org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ActivityEdge)_self,tokens);
    };
  }
  
  public static EList<Token> takeOfferedTokens(final ActivityEdge _self) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityEdgeAspectActivityEdgeAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityEdgeAspectActivityEdgeAspectContext.getSelf(_self);
    Object result = null;
    // #DispatchPointCut_before# EList<Token> takeOfferedTokens()
    if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ActivityEdge){
    	result = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityEdgeAspect._privk3_takeOfferedTokens(_self_, (org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ActivityEdge)_self);
    };
    return (org.eclipse.emf.common.util.EList<org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Token>)result;
  }
  
  public static boolean hasOffer(final ActivityEdge _self) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityEdgeAspectActivityEdgeAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityEdgeAspectActivityEdgeAspectContext.getSelf(_self);
    Object result = null;
    // #DispatchPointCut_before# boolean hasOffer()
    if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ActivityEdge){
    	result = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityEdgeAspect._privk3_hasOffer(_self_, (org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ActivityEdge)_self);
    };
    return (boolean)result;
  }
  
  @Containment
  public static EList<Offer> offers(final ActivityEdge _self) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityEdgeAspectActivityEdgeAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityEdgeAspectActivityEdgeAspectContext.getSelf(_self);
    Object result = null;
    // #DispatchPointCut_before# EList<Offer> offers()
    if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ActivityEdge){
    	result = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityEdgeAspect._privk3_offers(_self_, (org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ActivityEdge)_self);
    };
    return (org.eclipse.emf.common.util.EList<org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Offer>)result;
  }
  
  @Containment
  public static void offers(final ActivityEdge _self, final EList<Offer> offers) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityEdgeAspectActivityEdgeAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityEdgeAspectActivityEdgeAspectContext.getSelf(_self);
    // #DispatchPointCut_before# void offers(EList<Offer>)
    if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ActivityEdge){
    	org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityEdgeAspect._privk3_offers(_self_, (org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ActivityEdge)_self,offers);
    };
  }
  
  protected static void _privk3_sendOffer(final ActivityEdgeAspectActivityEdgeAspectProperties _self_, final ActivityEdge _self, final EList<Token> tokens) {
    final Offer offer = ActivitydiagramFactory.eINSTANCE.createOffer();
    _self.getOffers().add(offer);
    final Consumer<Token> _function = (Token token) -> {
      offer.getOfferedTokens().add(token);
    };
    tokens.forEach(_function);
  }
  
  protected static EList<Token> _privk3_takeOfferedTokens(final ActivityEdgeAspectActivityEdgeAspectProperties _self_, final ActivityEdge _self) {
    final BasicEList<Token> tokens = new BasicEList<Token>();
    final Consumer<Offer> _function = (Offer o) -> {
      tokens.addAll(o.getOfferedTokens());
    };
    _self.getOffers().forEach(_function);
    _self.getOffers().clear();
    return tokens;
  }
  
  protected static boolean _privk3_hasOffer(final ActivityEdgeAspectActivityEdgeAspectProperties _self_, final ActivityEdge _self) {
    final Function1<Offer, Boolean> _function = (Offer o1) -> {
      return Boolean.valueOf(OfferAspect.hasTokens(o1));
    };
    return IterableExtensions.<Offer>exists(_self.getOffers(), _function);
  }
  
  protected static EList<Offer> _privk3_offers(final ActivityEdgeAspectActivityEdgeAspectProperties _self_, final ActivityEdge _self) {
    try {
    	for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    		if (m.getName().equals("getOffers") &&
    			m.getParameterTypes().length == 0) {
    				Object ret = m.invoke(_self);
    				if (ret != null) {
    					return (org.eclipse.emf.common.util.EList) ret;
    				} else {
    					return null;
    				}
    		}
    	}
    } catch (Exception e) {
    	// Chut !
    }
    return _self_.offers;
  }
  
  protected static void _privk3_offers(final ActivityEdgeAspectActivityEdgeAspectProperties _self_, final ActivityEdge _self, final EList<Offer> offers) {
    boolean setterCalled = false;
    try {
    	for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    		if (m.getName().equals("setOffers")
    				&& m.getParameterTypes().length == 1) {
    			m.invoke(_self, offers);
    			setterCalled = true;
    		}
    	}
    } catch (Exception e) {
    	// Chut !
    }
    if (!setterCalled) {
    	_self_.offers = offers;
    }
  }
}
