package org.eclipse.gemoc.execution.sequential.javaengine.tests.wrapper;

import java.util.Set;
import org.eclipse.emf.common.util.URI;
import org.eclipse.gemoc.execution.sequential.javaengine.PlainK3ExecutionEngine;
import org.eclipse.gemoc.execution.sequential.javaengine.SequentialModelExecutionContext;
import org.eclipse.gemoc.executionframework.test.lib.IEngineWrapper;
import org.eclipse.gemoc.executionframework.test.lib.IExecutableModel;
import org.eclipse.gemoc.executionframework.test.lib.ILanguageWrapper;
import org.eclipse.gemoc.executionframework.test.lib.impl.TestRunConfiguration;
import org.eclipse.gemoc.xdsmlframework.api.core.ExecutionMode;
import org.eclipse.gemoc.xdsmlframework.api.core.IExecutionEngine;
import org.eclipse.gemoc.xdsmlframework.api.core.IRunConfiguration;
import org.eclipse.xtext.xbase.lib.Exceptions;

@SuppressWarnings("all")
public class JavaEngineWrapper implements IEngineWrapper {
  private PlainK3ExecutionEngine engine;
  
  @Override
  public void run() {
    try {
      this.engine.start();
      this.engine.joinThread();
      if ((this.engine.error != null)) {
        throw this.engine.error;
      }
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
  
  @Override
  public void prepare(final ILanguageWrapper wrapper, final IExecutableModel model, final Set<String> addons, final URI uri) {
    try {
      PlainK3ExecutionEngine _plainK3ExecutionEngine = new PlainK3ExecutionEngine();
      this.engine = _plainK3ExecutionEngine;
      final IRunConfiguration runConf = new TestRunConfiguration(model, uri, wrapper, addons);
      final SequentialModelExecutionContext exeContext = new SequentialModelExecutionContext<IRunConfiguration>(runConf, ExecutionMode.Run);
      exeContext.initializeResourceModel();
      this.engine.initialize(exeContext);
      this.engine.stopOnAddonError = true;
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
  
  @Override
  public IExecutionEngine getRealEngine() {
    return this.engine;
  }
}
