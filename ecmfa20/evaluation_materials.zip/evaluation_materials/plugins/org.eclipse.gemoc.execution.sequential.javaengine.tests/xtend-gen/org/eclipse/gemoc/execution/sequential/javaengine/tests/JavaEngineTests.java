/**
 * Copyright (c) 2016, 2017 Inria and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *     Inria - initial API and implementation
 */
package org.eclipse.gemoc.execution.sequential.javaengine.tests;

import org.eclipse.gemoc.execution.sequential.javaengine.tests.languages.LegacyFSM;
import org.eclipse.gemoc.execution.sequential.javaengine.tests.languages.TFSM;
import org.eclipse.gemoc.execution.sequential.javaengine.tests.wrapper.JavaEngineWrapper;
import org.eclipse.gemoc.executionframework.test.lib.impl.TestHelper;
import org.eclipse.gemoc.executionframework.test.lib.impl.TestModel;
import org.junit.Test;

@SuppressWarnings("all")
public class JavaEngineTests {
  public final static String tfsmModelsPlugin = "org.eclipse.gemoc.sample.tfsm.sequential.single_traffic_light_sample";
  
  public final static String legacyFsmModelsPlugin = "org.eclipse.gemoc.sample.legacyfsm.model_examples";
  
  @Test
  public void testTFSM() {
    JavaEngineWrapper _javaEngineWrapper = new JavaEngineWrapper();
    TFSM _tFSM = new TFSM();
    TestModel _testModel = new TestModel(JavaEngineTests.tfsmModelsPlugin, "/", "single_traffic_light.xtfsm", "", "");
    TestHelper.testWithoutExtraAddons(_javaEngineWrapper, _tFSM, _testModel);
  }
  
  @Test
  public void testTFSMGenericTrace() {
    JavaEngineWrapper _javaEngineWrapper = new JavaEngineWrapper();
    TFSM _tFSM = new TFSM();
    TestModel _testModel = new TestModel(JavaEngineTests.tfsmModelsPlugin, "/", "single_traffic_light.xtfsm", "", "");
    TestHelper.testWithGenericTrace(_javaEngineWrapper, _tFSM, _testModel);
  }
  
  @Test
  public void testLegacyFSM() {
    JavaEngineWrapper _javaEngineWrapper = new JavaEngineWrapper();
    LegacyFSM _legacyFSM = new LegacyFSM();
    TestModel _testModel = new TestModel(JavaEngineTests.legacyFsmModelsPlugin, "/", "BitShifting.fsm", "000101010", "?lang=org.eclipse.gemoc.sample.legacyfsm.xsfsm.XSFSM");
    TestHelper.testWithGenericTrace(_javaEngineWrapper, _legacyFSM, _testModel);
  }
  
  @Test
  public void testLegacyFSMGenericTrace() {
    JavaEngineWrapper _javaEngineWrapper = new JavaEngineWrapper();
    LegacyFSM _legacyFSM = new LegacyFSM();
    TestModel _testModel = new TestModel(JavaEngineTests.legacyFsmModelsPlugin, "/", "BitShifting.fsm", "000101010", "?lang=org.eclipse.gemoc.sample.legacyfsm.xsfsm.XSFSM");
    TestHelper.testWithoutExtraAddons(_javaEngineWrapper, _legacyFSM, _testModel);
  }
}
