package org.eclipse.gemoc.executionframework.property.monitor.esper;

public enum TruthValue {
	SATISFIED, VIOLATED, UNKNOWN
}
