package org.eclipse.gemoc.executionframework.property.monitor.esper.properties;

import java.util.List;
import java.util.Map;
import org.eclipse.gemoc.executionframework.property.model.property.Existence;
import org.eclipse.gemoc.executionframework.property.monitor.esper.TruthValue;
import org.eclipse.gemoc.executionframework.property.monitor.esper.properties.AbstractTemporalProperty;
import org.eclipse.viatra.query.patternlanguage.emf.specification.SpecificationBuilder;
import org.eclipse.viatra.query.runtime.api.IQuerySpecification;
import org.eclipse.xtend2.lib.StringConcatenation;

@SuppressWarnings("all")
public class ExistsPGlobally extends AbstractTemporalProperty {
  private final Existence exists;
  
  private final IQuerySpecification<?> p;
  
  public ExistsPGlobally(final SpecificationBuilder builder, final String name, final Existence exists) {
    super(builder, name);
    this.exists = exists;
    this.p = builder.getOrCreateSpecification(exists.getPattern());
    this.queries.put(this.p.getFullyQualifiedName(), this.p);
  }
  
  @Override
  protected String getStatementString() {
    final String pFqn = this.getFqn(this.p);
    final String pattern = this.getPattern();
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("select * from ");
    String _name = this.getName();
    _builder.append(_name);
    _builder.newLineIfNotEmpty();
    _builder.append("match_recognize (");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("measures P as P, P2 as P2");
    _builder.newLine();
    _builder.append("\t");
    _builder.append(pattern, "\t");
    _builder.newLineIfNotEmpty();
    _builder.append("\t");
    _builder.append("define");
    _builder.newLine();
    _builder.append("\t\t");
    _builder.append("P as P.");
    _builder.append(pFqn, "\t\t");
    _builder.append("? is not null,");
    _builder.newLineIfNotEmpty();
    _builder.append("\t\t");
    _builder.append("P2 as P2.");
    _builder.append(pFqn, "\t\t");
    _builder.append("? is not null,");
    _builder.newLineIfNotEmpty();
    _builder.append("\t\t");
    _builder.append("nP as nP.");
    _builder.append(pFqn, "\t\t");
    _builder.append("? is null,");
    _builder.newLineIfNotEmpty();
    _builder.append("\t\t");
    _builder.append("EoE as EoE.executionAboutToStop? is not null");
    String _xifexpression = null;
    boolean _contains = pattern.contains("P1");
    if (_contains) {
      _xifexpression = ((",\nP1 as P1." + pFqn) + "? is not null");
    }
    _builder.append(_xifexpression, "\t\t");
    _builder.newLineIfNotEmpty();
    _builder.append(")");
    _builder.newLine();
    final String result = _builder.toString();
    return result;
  }
  
  private String rec(final int i) {
    int _min = this.exists.getMin();
    int _minus = (_min - 1);
    boolean _lessThan = (i < _minus);
    if (_lessThan) {
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("nP*? (EoE | P1 ");
      String _rec = this.rec((i + 1));
      _builder.append(_rec);
      _builder.append(")");
      return _builder.toString();
    }
    int _max = this.exists.getMax();
    boolean _greaterThan = (_max > 0);
    if (_greaterThan) {
      int _max_1 = this.exists.getMax();
      boolean _lessThan_1 = (i < _max_1);
      if (_lessThan_1) {
        StringConcatenation _builder_1 = new StringConcatenation();
        _builder_1.append("nP*? (EoE | P ");
        String _rec_1 = this.rec((i + 1));
        _builder_1.append(_rec_1);
        _builder_1.append(")");
        return _builder_1.toString();
      } else {
        StringConcatenation _builder_2 = new StringConcatenation();
        _builder_2.append("nP*? (EoE | P2)");
        return _builder_2.toString();
      }
    } else {
      StringConcatenation _builder_3 = new StringConcatenation();
      _builder_3.append("nP*? (EoE | P)");
      return _builder_3.toString();
    }
  }
  
  private String getPattern() {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("pattern (");
    String _rec = this.rec(0);
    _builder.append(_rec);
    _builder.append(")");
    _builder.newLineIfNotEmpty();
    return _builder.toString();
  }
  
  @Override
  protected TruthValue getStatus(final Map<String, List<Map<?, ?>>> events) {
    final List<Map<?, ?>> lP = events.get("P");
    final List<Map<?, ?>> lP2 = events.get("P2");
    final boolean reachedP = (!((lP == null) || lP.isEmpty()));
    final boolean reachedP2 = (!((lP2 == null) || lP2.isEmpty()));
    TruthValue _xifexpression = null;
    if (((!reachedP2) && reachedP)) {
      _xifexpression = TruthValue.SATISFIED;
    } else {
      _xifexpression = TruthValue.VIOLATED;
    }
    return _xifexpression;
  }
}
