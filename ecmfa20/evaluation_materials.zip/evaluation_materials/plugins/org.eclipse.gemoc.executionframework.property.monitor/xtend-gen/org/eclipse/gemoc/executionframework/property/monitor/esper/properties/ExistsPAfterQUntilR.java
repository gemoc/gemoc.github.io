package org.eclipse.gemoc.executionframework.property.monitor.esper.properties;

import java.util.List;
import java.util.Map;
import org.eclipse.gemoc.executionframework.property.model.property.AfterUntil;
import org.eclipse.gemoc.executionframework.property.model.property.Existence;
import org.eclipse.gemoc.executionframework.property.monitor.esper.TruthValue;
import org.eclipse.gemoc.executionframework.property.monitor.esper.properties.AbstractTemporalProperty;
import org.eclipse.viatra.query.patternlanguage.emf.specification.SpecificationBuilder;
import org.eclipse.viatra.query.runtime.api.IQuerySpecification;
import org.eclipse.xtend2.lib.StringConcatenation;

@SuppressWarnings("all")
public class ExistsPAfterQUntilR extends AbstractTemporalProperty {
  private final Existence exists;
  
  private final IQuerySpecification<?> p;
  
  private final IQuerySpecification<?> q;
  
  private final IQuerySpecification<?> r;
  
  public ExistsPAfterQUntilR(final SpecificationBuilder builder, final String name, final Existence exists, final AfterUntil afterUntil) {
    super(builder, name);
    this.exists = exists;
    this.p = builder.getOrCreateSpecification(exists.getPattern());
    this.q = builder.getOrCreateSpecification(afterUntil.getLowerBoundPattern());
    this.r = builder.getOrCreateSpecification(afterUntil.getUpperBoundPattern());
    this.queries.put(this.p.getFullyQualifiedName(), this.p);
    this.queries.put(this.q.getFullyQualifiedName(), this.q);
    this.queries.put(this.r.getFullyQualifiedName(), this.r);
  }
  
  @Override
  protected String getStatementString() {
    final String pFqn = this.getFqn(this.p);
    final String qFqn = this.getFqn(this.q);
    final String rFqn = this.getFqn(this.r);
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("select * from ");
    String _name = this.getName();
    _builder.append(_name);
    _builder.newLineIfNotEmpty();
    _builder.append("match_recognize (");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("measures P as P, Q as Q, EoE as EoE");
    _builder.newLine();
    _builder.append("\t");
    String _pattern = this.getPattern();
    _builder.append(_pattern, "\t");
    _builder.newLineIfNotEmpty();
    _builder.append("\t");
    _builder.append("define");
    _builder.newLine();
    _builder.append("\t\t");
    _builder.append("P as P.");
    _builder.append(pFqn, "\t\t");
    _builder.append("? is not null,");
    _builder.newLineIfNotEmpty();
    _builder.append("\t\t");
    _builder.append("P1 as P1.");
    _builder.append(pFqn, "\t\t");
    _builder.append("? is not null,");
    _builder.newLineIfNotEmpty();
    _builder.append("\t\t");
    _builder.append("nP as nP.");
    _builder.append(pFqn, "\t\t");
    _builder.append("? is null,");
    _builder.newLineIfNotEmpty();
    _builder.append("\t\t");
    _builder.append("Q as Q.");
    _builder.append(qFqn, "\t\t");
    _builder.append("? is not null,");
    _builder.newLineIfNotEmpty();
    _builder.append("\t\t");
    _builder.append("R as R.");
    _builder.append(rFqn, "\t\t");
    _builder.append("? is not null,");
    _builder.newLineIfNotEmpty();
    _builder.append("\t\t");
    _builder.append("EoE as EoE.executionAboutToStop? is not null");
    _builder.newLine();
    _builder.append(")");
    _builder.newLine();
    final String result = _builder.toString();
    return result;
  }
  
  private String rec(final int i) {
    int _min = this.exists.getMin();
    int _minus = (_min - 1);
    boolean _lessThan = (i < _minus);
    if (_lessThan) {
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("nP*? (EoE | R | P1 ");
      String _rec = this.rec((i + 1));
      _builder.append(_rec);
      _builder.append(")");
      return _builder.toString();
    }
    int _max = this.exists.getMax();
    boolean _greaterThan = (_max > 0);
    if (_greaterThan) {
      int _max_1 = this.exists.getMax();
      boolean _lessThan_1 = (i < _max_1);
      if (_lessThan_1) {
        StringConcatenation _builder_1 = new StringConcatenation();
        _builder_1.append("nP*? (EoE | R | P ");
        String _rec_1 = this.rec((i + 1));
        _builder_1.append(_rec_1);
        _builder_1.append(")");
        return _builder_1.toString();
      } else {
        StringConcatenation _builder_2 = new StringConcatenation();
        _builder_2.append("nP*? (EoE | R | P1)");
        return _builder_2.toString();
      }
    } else {
      StringConcatenation _builder_3 = new StringConcatenation();
      _builder_3.append("nP*? (EoE | R | P)");
      return _builder_3.toString();
    }
  }
  
  private String getPattern() {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("pattern (EoE | Q ");
    String _rec = this.rec(0);
    _builder.append(_rec);
    _builder.append(")");
    _builder.newLineIfNotEmpty();
    final String pattern = _builder.toString();
    return pattern;
  }
  
  @Override
  protected TruthValue getStatus(final Map<String, List<Map<?, ?>>> events) {
    final List<Map<?, ?>> lQ = events.get("Q");
    final boolean reachedQ = (!((lQ == null) || lQ.isEmpty()));
    if (reachedQ) {
      final List<Map<?, ?>> lP = events.get("P");
      final boolean reachedP = (!((lP == null) || lP.isEmpty()));
      final List<Map<?, ?>> execEnd = events.get("EoE");
      final boolean reachedEoE = (!((execEnd == null) || execEnd.isEmpty()));
      if (reachedP) {
        if (reachedEoE) {
          return TruthValue.SATISFIED;
        } else {
          return TruthValue.UNKNOWN;
        }
      } else {
        return TruthValue.VIOLATED;
      }
    } else {
      return TruthValue.SATISFIED;
    }
  }
}
