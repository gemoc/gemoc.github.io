package org.eclipse.gemoc.executionframework.property.monitor.esper.properties;

import java.util.List;
import java.util.Map;
import org.eclipse.gemoc.executionframework.property.model.property.AfterUntil;
import org.eclipse.gemoc.executionframework.property.model.property.Universality;
import org.eclipse.gemoc.executionframework.property.monitor.esper.TruthValue;
import org.eclipse.gemoc.executionframework.property.monitor.esper.properties.AbstractTemporalProperty;
import org.eclipse.viatra.query.patternlanguage.emf.specification.SpecificationBuilder;
import org.eclipse.viatra.query.runtime.api.IQuerySpecification;
import org.eclipse.xtend2.lib.StringConcatenation;

@SuppressWarnings("all")
public class AlwaysPAfterQUntilR extends AbstractTemporalProperty {
  private final IQuerySpecification<?> p;
  
  private final IQuerySpecification<?> q;
  
  private final IQuerySpecification<?> r;
  
  public AlwaysPAfterQUntilR(final SpecificationBuilder builder, final String name, final Universality always, final AfterUntil afterUntil) {
    super(builder, name);
    this.p = builder.getOrCreateSpecification(always.getPattern());
    this.q = builder.getOrCreateSpecification(afterUntil.getLowerBoundPattern());
    this.r = builder.getOrCreateSpecification(afterUntil.getUpperBoundPattern());
    this.queries.put(this.p.getFullyQualifiedName(), this.p);
    this.queries.put(this.q.getFullyQualifiedName(), this.q);
    this.queries.put(this.r.getFullyQualifiedName(), this.r);
  }
  
  @Override
  protected String getStatementString() {
    final String pFqn = this.getFqn(this.p);
    final String qFqn = this.getFqn(this.q);
    final String rFqn = this.getFqn(this.r);
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("select * from ");
    String _name = this.getName();
    _builder.append(_name);
    _builder.newLineIfNotEmpty();
    _builder.append("match_recognize (");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("measures nP as nP, EoE as EoE");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("pattern (EoE | (Q P*? (R | EoE | nP)))");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("define");
    _builder.newLine();
    _builder.append("\t\t");
    _builder.append("P as P.");
    _builder.append(pFqn, "\t\t");
    _builder.append("? is not null,");
    _builder.newLineIfNotEmpty();
    _builder.append("\t\t");
    _builder.append("nP as nP.");
    _builder.append(pFqn, "\t\t");
    _builder.append("? is null,");
    _builder.newLineIfNotEmpty();
    _builder.append("\t\t");
    _builder.append("Q as Q.");
    _builder.append(qFqn, "\t\t");
    _builder.append("? is not null,");
    _builder.newLineIfNotEmpty();
    _builder.append("\t\t");
    _builder.append("R as R.");
    _builder.append(rFqn, "\t\t");
    _builder.append("? is not null,");
    _builder.newLineIfNotEmpty();
    _builder.append("\t\t");
    _builder.append("EoE as EoE.executionAboutToStop? is not null");
    _builder.newLine();
    _builder.append(")");
    _builder.newLine();
    final String result = _builder.toString();
    return result;
  }
  
  @Override
  protected TruthValue getStatus(final Map<String, List<Map<?, ?>>> events) {
    final List<Map<?, ?>> execEnd = events.get("EoE");
    final List<Map<?, ?>> lnP = events.get("nP");
    if (((lnP == null) || lnP.isEmpty())) {
      TruthValue _xifexpression = null;
      if (((execEnd == null) || execEnd.isEmpty())) {
        _xifexpression = TruthValue.UNKNOWN;
      } else {
        _xifexpression = TruthValue.SATISFIED;
      }
      return _xifexpression;
    } else {
      return TruthValue.VIOLATED;
    }
  }
}
