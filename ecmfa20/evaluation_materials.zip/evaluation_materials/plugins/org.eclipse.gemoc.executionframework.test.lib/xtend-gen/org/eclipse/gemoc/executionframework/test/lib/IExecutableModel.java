package org.eclipse.gemoc.executionframework.test.lib;

@SuppressWarnings("all")
public interface IExecutableModel {
  public abstract String getFileName();
  
  public abstract String getPluginName();
  
  public abstract String getFolderPath();
  
  public abstract String getMelangeQuery();
  
  public abstract String getInitArgument();
  
  public abstract int getShouldStopAfter();
}
