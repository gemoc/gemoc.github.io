package org.eclipse.gemoc.executionframework.test.lib;

import java.util.Set;
import org.eclipse.emf.common.util.URI;
import org.eclipse.gemoc.executionframework.test.lib.IExecutableModel;
import org.eclipse.gemoc.executionframework.test.lib.ILanguageWrapper;
import org.eclipse.gemoc.xdsmlframework.api.core.IExecutionEngine;

@SuppressWarnings("all")
public interface IEngineWrapper {
  public abstract void prepare(final ILanguageWrapper wrapper, final IExecutableModel model, final Set<String> addons, final URI uri);
  
  public abstract void run();
  
  public abstract IExecutionEngine getRealEngine();
}
