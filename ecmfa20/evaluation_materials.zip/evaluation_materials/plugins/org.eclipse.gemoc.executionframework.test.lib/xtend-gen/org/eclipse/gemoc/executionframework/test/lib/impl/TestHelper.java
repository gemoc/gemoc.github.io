package org.eclipse.gemoc.executionframework.test.lib.impl;

import java.io.File;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Collections;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.core.runtime.jobs.Job;
import org.eclipse.emf.common.util.URI;
import org.eclipse.gemoc.executionframework.test.lib.IEngineWrapper;
import org.eclipse.gemoc.executionframework.test.lib.IExecutableModel;
import org.eclipse.gemoc.executionframework.test.lib.ILanguageWrapper;
import org.eclipse.gemoc.executionframework.test.lib.impl.TestEngineAddon;
import org.eclipse.gemoc.executionframework.test.lib.impl.TestUtil;
import org.eclipse.gemoc.trace.commons.model.trace.Trace;
import org.eclipse.gemoc.trace.gemoc.traceaddon.GenericTraceEngineAddon;
import org.eclipse.gemoc.xdsmlframework.api.engine_addon.IEngineAddon;
import org.eclipse.xtext.xbase.lib.CollectionLiterals;
import org.eclipse.xtext.xbase.lib.Exceptions;
import org.eclipse.xtext.xbase.lib.InputOutput;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.junit.Assert;

@SuppressWarnings("all")
public class TestHelper {
  public static class TestResult {
    public long executionDuration;
    
    public Trace<?, ?, ?> trace;
    
    public int amountOfStepsExecuted = 0;
    
    public boolean engineAboutToStart = false;
    
    public boolean engineAboutToStop = false;
    
    public boolean engineStarted = false;
    
    public boolean engineStopped = false;
    
    public boolean engineAboutToDispose = false;
  }
  
  private static TestHelper.TestResult testInternal(final IProgressMonitor m, final IEngineWrapper engine, final ILanguageWrapper language, final Set<String> addons, final Set<IEngineAddon> otherAddons, final IExecutableModel model, final boolean cleanup) {
    try {
      final IProject eclipseProject = ResourcesPlugin.getWorkspace().getRoot().getProject(
        Integer.valueOf(Math.abs(new Random().nextInt())).toString());
      boolean _exists = eclipseProject.exists();
      if (_exists) {
        eclipseProject.delete(true, m);
      }
      eclipseProject.create(m);
      eclipseProject.open(m);
      final IFile file = eclipseProject.getFile(model.getFileName());
      String _folderPath = model.getFolderPath();
      File _file = new File(_folderPath);
      String _fileName = model.getFileName();
      final String filePath = new File(_file, _fileName).getAbsolutePath();
      TestUtil.copyFileFromPlugin(model.getPluginName(), filePath, file, m);
      final URI modelURI = URI.createPlatformResourceURI(file.getFullPath().toString(), true);
      int _shouldStopAfter = model.getShouldStopAfter();
      final TestEngineAddon testAddon = new TestEngineAddon(_shouldStopAfter);
      engine.prepare(language, model, addons, modelURI);
      for (final IEngineAddon otherAddon : otherAddons) {
        {
          InputOutput.<String>println("loading other addons");
          engine.getRealEngine().getExecutionContext().getExecutionPlatform().addEngineAddon(otherAddon);
        }
      }
      InputOutput.<String>println("loading test addons");
      engine.getRealEngine().getExecutionContext().getExecutionPlatform().addEngineAddon(testAddon);
      engine.run();
      engine.getRealEngine().dispose();
      final TestHelper.TestResult testResult = testAddon.getTestResult();
      if (cleanup) {
        eclipseProject.delete(true, true, m);
      }
      return testResult;
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
  
  public static TestHelper.TestResult testWithJob(final IEngineWrapper engine, final ILanguageWrapper language, final Set<String> addons, final Set<IEngineAddon> otherAddons, final IExecutableModel model, final boolean cleanup) {
    try {
      final Set<TestHelper.TestResult> out = new HashSet<TestHelper.TestResult>();
      final Job job = new Job("single test case") {
        @Override
        protected IStatus run(final IProgressMonitor m) {
          try {
            final TestHelper.TestResult testResult = TestHelper.testInternal(m, engine, language, addons, otherAddons, model, cleanup);
            out.add(testResult);
            return Status.OK_STATUS;
          } catch (final Throwable _t) {
            if (_t instanceof Throwable) {
              final Throwable t = (Throwable)_t;
              t.printStackTrace();
              final StringWriter sw = new StringWriter();
              PrintWriter _printWriter = new PrintWriter(sw);
              t.printStackTrace(_printWriter);
              final Status errorStatus = new Status(Status.ERROR, "test", "An error occured in the test case", t);
              return errorStatus;
            } else {
              throw Exceptions.sneakyThrow(_t);
            }
          }
        }
      };
      job.schedule();
      TestUtil.waitForJobs();
      if (((job.getResult() != null) && (job.getResult().getException() != null))) {
        throw job.getResult().getException();
      }
      return IterableExtensions.<TestHelper.TestResult>head(out);
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
  
  public static TestHelper.TestResult testWithGenericTrace(final IEngineWrapper engine, final ILanguageWrapper language, final IExecutableModel model, final boolean cleanup) {
    final GenericTraceEngineAddon traceAddon = new GenericTraceEngineAddon();
    final TestHelper.TestResult testResult = TestHelper.testWithJob(engine, language, Collections.<String>unmodifiableSet(CollectionLiterals.<String>newHashSet()), Collections.<IEngineAddon>unmodifiableSet(CollectionLiterals.<IEngineAddon>newHashSet(traceAddon)), model, cleanup);
    testResult.trace = traceAddon.getTrace();
    return testResult;
  }
  
  public static TestHelper.TestResult testWithGenericTrace(final IEngineWrapper engine, final ILanguageWrapper language, final IExecutableModel model) {
    return TestHelper.testWithGenericTrace(engine, language, model, false);
  }
  
  public static TestHelper.TestResult testWithoutExtraAddons(final IEngineWrapper engine, final ILanguageWrapper language, final IExecutableModel model, final boolean cleanup) {
    return TestHelper.testWithJob(engine, language, Collections.<String>unmodifiableSet(CollectionLiterals.<String>newHashSet()), Collections.<IEngineAddon>unmodifiableSet(CollectionLiterals.<IEngineAddon>newHashSet()), model, cleanup);
  }
  
  public static TestHelper.TestResult testWithoutExtraAddons(final IEngineWrapper engine, final ILanguageWrapper language, final IExecutableModel model) {
    return TestHelper.testWithoutExtraAddons(engine, language, model, false);
  }
  
  public static TestHelper.TestResult testNoAssert(final IEngineWrapper engine, final ILanguageWrapper language, final IExecutableModel model, final boolean cleanup) {
    final TestHelper.TestResult res = TestHelper.testWithJob(engine, language, Collections.<String>unmodifiableSet(CollectionLiterals.<String>newHashSet()), Collections.<IEngineAddon>unmodifiableSet(CollectionLiterals.<IEngineAddon>newHashSet()), model, cleanup);
    return res;
  }
  
  public static void genericAsserts(final TestHelper.TestResult testResult) {
    Assert.assertTrue("No steps were executed", (testResult.amountOfStepsExecuted > 0));
    Assert.assertTrue("engineAboutToStart never performed", testResult.engineAboutToStart);
    Assert.assertTrue("engineStarted never performed", testResult.engineStarted);
    Assert.assertTrue("engineAboutToStop never performed", testResult.engineAboutToStop);
    Assert.assertTrue("engineStopped never performed", testResult.engineStopped);
    Assert.assertTrue("engineAboutToDispose never performed", testResult.engineAboutToDispose);
  }
  
  public static void cleanWorkspace() {
    final Job job = new Job("cleanup workspace") {
      @Override
      protected IStatus run(final IProgressMonitor m) {
        try {
          IProject[] _projects = ResourcesPlugin.getWorkspace().getRoot().getProjects();
          for (final IProject p : _projects) {
            p.delete(true, m);
          }
          return Status.OK_STATUS;
        } catch (Throwable _e) {
          throw Exceptions.sneakyThrow(_e);
        }
      }
    };
    job.schedule();
    TestUtil.waitForJobs();
  }
}
