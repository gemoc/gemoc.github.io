package org.eclipse.gemoc.executionframework.test.lib;

@SuppressWarnings("all")
public interface ILanguageWrapper {
  public abstract String getEntryPoint();
  
  public abstract String getLanguageName();
  
  public abstract String getInitializationMethod();
}
