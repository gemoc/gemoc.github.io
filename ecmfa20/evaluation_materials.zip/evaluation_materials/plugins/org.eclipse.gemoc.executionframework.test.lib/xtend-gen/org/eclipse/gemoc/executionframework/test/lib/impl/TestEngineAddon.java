package org.eclipse.gemoc.executionframework.test.lib.impl;

import org.eclipse.gemoc.executionframework.test.lib.impl.TestHelper;
import org.eclipse.gemoc.trace.commons.model.trace.Step;
import org.eclipse.gemoc.xdsmlframework.api.core.IExecutionEngine;
import org.eclipse.gemoc.xdsmlframework.api.engine_addon.DefaultEngineAddon;
import org.eclipse.xtend.lib.annotations.AccessorType;
import org.eclipse.xtend.lib.annotations.Accessors;
import org.eclipse.xtext.xbase.lib.Pure;

@SuppressWarnings("all")
public class TestEngineAddon extends DefaultEngineAddon {
  private final int shouldStopAfter;
  
  private long timeStart;
  
  @Accessors({ AccessorType.PRIVATE_SETTER, AccessorType.PUBLIC_GETTER })
  private final TestHelper.TestResult testResult;
  
  public TestEngineAddon(final int shouldStopAfter) {
    this.shouldStopAfter = shouldStopAfter;
    TestHelper.TestResult _testResult = new TestHelper.TestResult();
    this.testResult = _testResult;
  }
  
  @Override
  public void engineAboutToDispose(final IExecutionEngine engine) {
    this.testResult.engineAboutToDispose = true;
  }
  
  @Override
  public void engineAboutToStart(final IExecutionEngine engine) {
    this.testResult.engineAboutToStart = true;
  }
  
  @Override
  public void engineAboutToStop(final IExecutionEngine engine) {
    this.testResult.engineAboutToStop = true;
    final long timeEnd = System.nanoTime();
    this.testResult.executionDuration = (timeEnd - this.timeStart);
  }
  
  @Override
  public void engineStarted(final IExecutionEngine executionEngine) {
    this.testResult.engineStarted = true;
    this.timeStart = System.nanoTime();
  }
  
  @Override
  public void engineStopped(final IExecutionEngine engine) {
    this.testResult.engineStopped = true;
  }
  
  @Override
  public void stepExecuted(final IExecutionEngine<?> engine, final Step<?> stepExecuted) {
    this.testResult.amountOfStepsExecuted++;
    if (((this.shouldStopAfter != (-1)) && (this.shouldStopAfter < this.testResult.amountOfStepsExecuted))) {
      engine.stop();
    }
  }
  
  @Pure
  public TestHelper.TestResult getTestResult() {
    return this.testResult;
  }
}
