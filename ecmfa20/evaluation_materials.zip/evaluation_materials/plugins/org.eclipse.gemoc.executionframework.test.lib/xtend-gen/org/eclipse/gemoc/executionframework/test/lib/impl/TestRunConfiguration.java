package org.eclipse.gemoc.executionframework.test.lib.impl;

import com.google.common.base.Objects;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Set;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.gemoc.execution.sequential.javaengine.IK3RunConfiguration;
import org.eclipse.gemoc.executionframework.test.lib.IExecutableModel;
import org.eclipse.gemoc.executionframework.test.lib.ILanguageWrapper;
import org.eclipse.gemoc.xdsmlframework.api.extensions.engine_addon.EngineAddonSpecificationExtension;
import org.eclipse.gemoc.xdsmlframework.api.extensions.engine_addon.EngineAddonSpecificationExtensionPoint;
import org.eclipse.xtext.xbase.lib.Exceptions;
import org.eclipse.xtext.xbase.lib.IterableExtensions;

@SuppressWarnings("all")
public class TestRunConfiguration implements IK3RunConfiguration {
  private final ILanguageWrapper language;
  
  private final IExecutableModel model;
  
  private final Set<String> addonsToLoad;
  
  private final URI modelURI;
  
  public TestRunConfiguration(final IExecutableModel model, final URI modelURI, final ILanguageWrapper language, final Set<String> addonsToLoad) {
    this.language = language;
    this.model = model;
    this.addonsToLoad = addonsToLoad;
    this.modelURI = modelURI;
  }
  
  @Override
  public int getAnimationDelay() {
    return 0;
  }
  
  @Override
  public URI getAnimatorURI() {
    return null;
  }
  
  @Override
  public Collection<EngineAddonSpecificationExtension> getEngineAddonExtensions() {
    final List<EngineAddonSpecificationExtension> result = new ArrayList<EngineAddonSpecificationExtension>();
    final Collection<EngineAddonSpecificationExtension> loadedAddons = EngineAddonSpecificationExtensionPoint.getSpecifications();
    for (final EngineAddonSpecificationExtension ext : loadedAddons) {
      boolean _contains = this.addonsToLoad.contains(ext.getName());
      if (_contains) {
        result.add(ext);
      }
    }
    return result;
  }
  
  @Override
  public URI getExecutedModelAsMelangeURI() {
    boolean _isEmpty = this.getMelangeQuery().isEmpty();
    if (_isEmpty) {
      return this.modelURI;
    }
    String _replace = this.modelURI.toString().replace("platform:/", "melange:/");
    String _melangeQuery = this.getMelangeQuery();
    final String melangeURIString = (_replace + _melangeQuery);
    return URI.createURI(melangeURIString);
  }
  
  @Override
  public URI getExecutedModelURI() {
    return this.modelURI;
  }
  
  @Override
  public String getExecutionEntryPoint() {
    return this.language.getEntryPoint();
  }
  
  @Override
  public String getLanguageName() {
    return this.language.getLanguageName();
  }
  
  @Override
  public String getMelangeQuery() {
    String _xifexpression = null;
    String _melangeQuery = this.model.getMelangeQuery();
    boolean _equals = Objects.equal(_melangeQuery, null);
    if (_equals) {
      String _languageName = this.getLanguageName();
      _xifexpression = ("?lang=" + _languageName);
    } else {
      _xifexpression = this.model.getMelangeQuery();
    }
    return _xifexpression;
  }
  
  @Override
  public boolean getBreakStart() {
    return false;
  }
  
  @Override
  public String getDebugModelID() {
    return "org.eclipse.gemoc.execution.sequential.javaengine.ui.debugModel";
  }
  
  @Override
  public String getModelEntryPoint() {
    try {
      final ResourceSet resourceSet = new ResourceSetImpl();
      final Resource modelResource = resourceSet.createResource(this.modelURI);
      modelResource.load(null);
      final String result = modelResource.getURIFragment(IterableExtensions.<EObject>head(modelResource.getContents()));
      modelResource.unload();
      return result;
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
  
  @Override
  public String getModelInitializationArguments() {
    return this.model.getInitArgument();
  }
  
  @Override
  public String getModelInitializationMethod() {
    return this.language.getInitializationMethod();
  }
}
