package org.eclipse.gemoc.executionframework.test.lib.impl;

import org.eclipse.gemoc.executionframework.test.lib.IExecutableModel;
import org.eclipse.xtend.lib.annotations.AccessorType;
import org.eclipse.xtend.lib.annotations.Accessors;
import org.eclipse.xtext.xbase.lib.Pure;

@SuppressWarnings("all")
public class TestModel implements IExecutableModel {
  @Accessors({ AccessorType.PRIVATE_SETTER, AccessorType.PUBLIC_GETTER })
  private final String fileName;
  
  @Accessors({ AccessorType.PRIVATE_SETTER, AccessorType.PUBLIC_GETTER })
  private final String pluginName;
  
  @Accessors({ AccessorType.PRIVATE_SETTER, AccessorType.PUBLIC_GETTER })
  private final String folderPath;
  
  @Accessors({ AccessorType.PRIVATE_SETTER, AccessorType.PUBLIC_GETTER })
  private final String initArgument;
  
  @Accessors({ AccessorType.PRIVATE_SETTER, AccessorType.PUBLIC_GETTER })
  private final String melangeQuery;
  
  @Accessors({ AccessorType.PRIVATE_SETTER, AccessorType.PUBLIC_GETTER })
  private final int shouldStopAfter;
  
  public TestModel(final String pluginName, final String folderPath, final String fileName, final String initArgument, final String melangeQuery, final int shouldStopAfter) {
    this.pluginName = pluginName;
    this.folderPath = folderPath;
    this.fileName = fileName;
    this.initArgument = initArgument;
    this.melangeQuery = melangeQuery;
    this.shouldStopAfter = shouldStopAfter;
  }
  
  public TestModel(final String pluginName, final String folderPath, final String fileName) {
    this(pluginName, folderPath, fileName, "", "", (-1));
  }
  
  public TestModel(final String pluginName, final String folderPath, final String fileName, final String initArgument, final String melangeQuery) {
    this(pluginName, folderPath, fileName, initArgument, melangeQuery, (-1));
  }
  
  @Pure
  public String getFileName() {
    return this.fileName;
  }
  
  @Pure
  public String getPluginName() {
    return this.pluginName;
  }
  
  @Pure
  public String getFolderPath() {
    return this.folderPath;
  }
  
  @Pure
  public String getInitArgument() {
    return this.initArgument;
  }
  
  @Pure
  public String getMelangeQuery() {
    return this.melangeQuery;
  }
  
  @Pure
  public int getShouldStopAfter() {
    return this.shouldStopAfter;
  }
}
