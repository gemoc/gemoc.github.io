package org.eclipse.gemoc.executionframework.test.lib.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Map;
import java.util.Set;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.FileLocator;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.Path;
import org.eclipse.core.runtime.Platform;
import org.eclipse.core.runtime.jobs.Job;
import org.eclipse.gemoc.executionframework.engine.Activator;
import org.eclipse.gemoc.executionframework.engine.core.GemocRunningEnginesRegistry;
import org.eclipse.gemoc.xdsmlframework.api.core.EngineStatus;
import org.eclipse.gemoc.xdsmlframework.api.core.IExecutionEngine;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.IWindowListener;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.PlatformUI;
import org.eclipse.xtext.xbase.lib.Exceptions;
import org.osgi.framework.Bundle;

@SuppressWarnings("all")
public class TestUtil {
  public static void copyFileInWS(final File file, final IFolder destination, final IProgressMonitor m) {
    try {
      final IFile fileInProject = destination.getFile(file.getName());
      boolean _exists = fileInProject.exists();
      boolean _not = (!_exists);
      if (_not) {
        FileInputStream _fileInputStream = new FileInputStream(file);
        fileInProject.create(_fileInputStream, true, m);
      }
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
  
  public static IFolder copyFolderInWS(final File folder, final IResource destination, final IProgressMonitor m) {
    try {
      IFolder _xifexpression = null;
      if ((destination instanceof IProject)) {
        _xifexpression = ((IProject)destination).getFolder(folder.getName());
      } else {
        IFolder _xifexpression_1 = null;
        if ((destination instanceof IFolder)) {
          _xifexpression_1 = ((IFolder)destination).getFolder(folder.getName());
        } else {
          _xifexpression_1 = null;
        }
        _xifexpression = _xifexpression_1;
      }
      final IFolder folderCopy = _xifexpression;
      boolean _exists = folderCopy.exists();
      boolean _not = (!_exists);
      if (_not) {
        folderCopy.create(true, true, m);
      }
      File[] _listFiles = folder.listFiles();
      for (final File f : _listFiles) {
        boolean _isFile = f.isFile();
        if (_isFile) {
          TestUtil.copyFileInWS(f, folderCopy, m);
        } else {
          boolean _isDirectory = f.isDirectory();
          if (_isDirectory) {
            TestUtil.copyFolderInWS(f, folderCopy, m);
          }
        }
      }
      return folderCopy;
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
  
  public static void waitForJobs() {
    while ((!Job.getJobManager().isIdle())) {
      TestUtil.delay(100);
    }
  }
  
  public static void waitForJobsThenWindowClosed() {
    TestUtil.waitForJobsThenWait(1000000000);
  }
  
  public static void waitForJobsThenWait(final long waitTimeMillis) {
    TestUtil.waitForJobs();
    TestUtil.delay(waitTimeMillis);
  }
  
  public static void waitUIThread(final long waitTimeMillis) {
    TestUtil.delay(waitTimeMillis);
  }
  
  private static boolean closed = false;
  
  private static void delay(final long waitTimeMillis) {
    final Display display = Display.getCurrent();
    IWorkbench _workbench = PlatformUI.getWorkbench();
    _workbench.addWindowListener(
      new IWindowListener() {
        @Override
        public void windowActivated(final IWorkbenchWindow window) {
        }
        
        @Override
        public void windowClosed(final IWorkbenchWindow window) {
          TestUtil.closed = true;
        }
        
        @Override
        public void windowDeactivated(final IWorkbenchWindow window) {
        }
        
        @Override
        public void windowOpened(final IWorkbenchWindow window) {
        }
      });
    if ((display != null)) {
      long _currentTimeMillis = System.currentTimeMillis();
      final long endTimeMillis = (_currentTimeMillis + waitTimeMillis);
      while (((System.currentTimeMillis() < endTimeMillis) && (!TestUtil.closed))) {
        boolean _readAndDispatch = display.readAndDispatch();
        boolean _not = (!_readAndDispatch);
        if (_not) {
          display.sleep();
        }
      }
      display.update();
    } else {
      try {
        Thread.sleep(waitTimeMillis);
      } catch (final Throwable _t) {
        if (_t instanceof InterruptedException) {
        } else {
          throw Exceptions.sneakyThrow(_t);
        }
      }
    }
  }
  
  public static void removeStoppedEngines() {
    final GemocRunningEnginesRegistry registry = Activator.getDefault().gemocRunningEngineRegistry;
    Set<Map.Entry<String, IExecutionEngine<?>>> _entrySet = registry.getRunningEngines().entrySet();
    for (final Map.Entry<String, IExecutionEngine<?>> engineEntry : _entrySet) {
      boolean _equals = engineEntry.getValue().getRunningStatus().equals(EngineStatus.RunStatus.Stopped);
      if (_equals) {
        registry.unregisterEngine(engineEntry.getKey());
      }
    }
  }
  
  public static InputStream openFileFromPlugin(final String pluginName, final String pathInPlugin) {
    try {
      final Bundle bundle = Platform.getBundle(pluginName);
      final Path path = new Path(pathInPlugin);
      final InputStream stream = FileLocator.openStream(bundle, path, false);
      return stream;
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
  
  public static void copyFileFromPlugin(final String pluginName, final String pathInPlugin, final IFile targetFile, final IProgressMonitor m) {
    try {
      final InputStream stream = TestUtil.openFileFromPlugin(pluginName, pathInPlugin);
      targetFile.create(stream, true, m);
      stream.close();
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
}
