package org.eclipse.gemoc.executionframework.property.tests.thingml;

import java.util.Collection;
import org.eclipse.gemoc.executionframework.property.tests.AbstractMonitoringTimeBenchmarkTestSuite;
import org.eclipse.gemoc.executionframework.property.tests.languages.ThingML;
import org.eclipse.gemoc.executionframework.property.tests.thingml.ThingMLTestData;
import org.eclipse.gemoc.executionframework.test.lib.ILanguageWrapper;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

@RunWith(Parameterized.class)
@SuppressWarnings("all")
public class ThingMLMonitoringTimeBenchmarkingTest extends AbstractMonitoringTimeBenchmarkTestSuite {
  public ThingMLMonitoringTimeBenchmarkingTest(final String model, final int scenarioID) {
    super(model, scenarioID);
  }
  
  @Parameterized.Parameters(name = "{0}[{1}]")
  public static Collection<Object[]> data() {
    return ThingMLTestData.getData();
  }
  
  @Override
  public String getSemanticsPlugin() {
    return "thingml.xthingml";
  }
  
  @Override
  public ILanguageWrapper getDSL() {
    return new ThingML();
  }
  
  @Override
  public String getPluginName() {
    return "thingml.property.benchmark";
  }
}
