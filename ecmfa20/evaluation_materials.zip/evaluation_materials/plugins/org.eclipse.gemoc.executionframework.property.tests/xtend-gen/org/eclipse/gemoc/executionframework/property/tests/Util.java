package org.eclipse.gemoc.executionframework.property.tests;

import com.google.common.base.Objects;
import java.io.InputStream;
import java.lang.management.GarbageCollectorMXBean;
import java.lang.management.ManagementFactory;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.FileLocator;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Path;
import org.eclipse.core.runtime.Platform;
import org.eclipse.core.runtime.Status;
import org.eclipse.core.runtime.jobs.Job;
import org.eclipse.e4.core.contexts.IEclipseContext;
import org.eclipse.e4.core.internal.contexts.EclipseContext;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.gemoc.executionframework.engine.Activator;
import org.eclipse.gemoc.executionframework.test.lib.impl.TestUtil;
import org.eclipse.gemoc.xdsmlframework.api.core.EngineStatus;
import org.eclipse.gemoc.xdsmlframework.api.core.IExecutionEngine;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.internal.Workbench;
import org.eclipse.xtext.util.SimpleAttributeResolver;
import org.eclipse.xtext.util.SimpleCache;
import org.eclipse.xtext.xbase.lib.CollectionLiterals;
import org.eclipse.xtext.xbase.lib.Conversions;
import org.eclipse.xtext.xbase.lib.DoubleExtensions;
import org.eclipse.xtext.xbase.lib.Exceptions;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.Functions.Function2;
import org.eclipse.xtext.xbase.lib.IntegerRange;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.osgi.framework.Bundle;

@SuppressWarnings("all")
public class Util {
  public static Long mean(final Collection<Long> values) {
    final Function2<Long, Long, Long> _function = (Long p1, Long p2) -> {
      return Long.valueOf(((p1).longValue() + (p2).longValue()));
    };
    final Long sum = IterableExtensions.<Long>reduce(values, _function);
    int _size = values.size();
    return Long.valueOf(((sum).longValue() / _size));
  }
  
  public static Double meanDouble(final Collection<Double> values) {
    final Function2<Double, Double, Double> _function = (Double p1, Double p2) -> {
      return Double.valueOf(DoubleExtensions.operator_plus(p1, p2));
    };
    final Double sum = IterableExtensions.<Double>reduce(values, _function);
    int _size = values.size();
    return Double.valueOf(((sum).doubleValue() / _size));
  }
  
  public static Long median(final List<Long> values) {
    final List<Long> sorted = IterableExtensions.<Long>sort(values);
    int _size = sorted.size();
    final int middle = (_size / 2);
    int _size_1 = sorted.size();
    int _modulo = (_size_1 % 2);
    boolean _equals = (_modulo == 1);
    if (_equals) {
      return sorted.get(middle);
    } else {
      Long _get = sorted.get((middle - 1));
      Long _get_1 = sorted.get(middle);
      long _plus = ((_get).longValue() + (_get_1).longValue());
      return Long.valueOf((_plus / 2));
    }
  }
  
  public static String format(final int value, final int amountNumbers) {
    return String.format((("%0" + Integer.valueOf(amountNumbers)) + "d"), Integer.valueOf(value));
  }
  
  public static void cleanup(final String semanticsPlugin) {
    Util.gemocCleanUp();
    Util.k3CleanUp(semanticsPlugin);
    Util.xtextCleanUp();
    Util.eclipseCleanUp();
    Util.forceGcSettled();
  }
  
  private static Set<Map<?, ?>> k3Maps = new HashSet<Map<?, ?>>();
  
  public static void gemocCleanUp() {
    final Function1<Map.Entry<String, IExecutionEngine<?>>, Boolean> _function = (Map.Entry<String, IExecutionEngine<?>> it) -> {
      EngineStatus.RunStatus _runningStatus = it.getValue().getRunningStatus();
      return Boolean.valueOf(Objects.equal(_runningStatus, EngineStatus.RunStatus.Stopped));
    };
    final Iterable<Map.Entry<String, IExecutionEngine<?>>> stoppedEnginesEntries = IterableExtensions.<Map.Entry<String, IExecutionEngine<?>>>filter(Activator.getDefault().gemocRunningEngineRegistry.getRunningEngines().entrySet(), _function);
    final HashSet<ResourceSet> resourceSets = new HashSet<ResourceSet>();
    for (final Map.Entry<String, IExecutionEngine<?>> stopped : stoppedEnginesEntries) {
      {
        final ResourceSet resourceSet = stopped.getValue().getExecutionContext().getResourceModel().getResourceSet();
        resourceSets.add(resourceSet);
        EList<Resource> _resources = resourceSet.getResources();
        for (final Resource resource : _resources) {
          {
            resource.eAdapters().clear();
            resource.unload();
          }
        }
        stopped.getValue().dispose();
        Activator.getDefault().gemocRunningEngineRegistry.unregisterEngine(stopped.getKey());
      }
    }
    for (final ResourceSet resourceSet : resourceSets) {
      resourceSet.getResources().clear();
    }
  }
  
  public static void k3CleanUp(final String semanticsPlugin) {
    try {
      boolean _isEmpty = Util.k3Maps.isEmpty();
      if (_isEmpty) {
        final Bundle bundle = Platform.getBundle(semanticsPlugin);
        final Enumeration<URL> bundleIterator = bundle.findEntries("/", "*Context.class", true);
        while (bundleIterator.hasMoreElements()) {
          {
            final URL bundleElement = bundleIterator.nextElement();
            final String className = bundleElement.getFile().replaceFirst("/bin/", "").replaceFirst(".class", "").replaceAll("/", ".");
            final Class<?> c = bundle.loadClass(className);
            final Function1<Field, Boolean> _function = (Field it) -> {
              String _name = it.getName();
              return Boolean.valueOf(Objects.equal(_name, "INSTANCE"));
            };
            boolean _exists = IterableExtensions.<Field>exists(((Iterable<Field>)Conversions.doWrapArray(c.getFields())), _function);
            if (_exists) {
              final Field instanceField = c.getField("INSTANCE");
              final Object instance = instanceField.get(c);
              final Function1<Method, Boolean> _function_1 = (Method it) -> {
                String _name = it.getName();
                return Boolean.valueOf(Objects.equal(_name, "getMap"));
              };
              final Method mapGetter = IterableExtensions.<Method>findFirst(((Iterable<Method>)Conversions.doWrapArray(instance.getClass().getMethods())), _function_1);
              Object _invoke = mapGetter.invoke(instance);
              final Map<?, ?> map = ((Map<?, ?>) _invoke);
              Util.k3Maps.add(map);
            }
          }
        }
      }
      for (final Map<?, ?> m : Util.k3Maps) {
        m.clear();
      }
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
  
  public static void xtextCleanUp() {
    try {
      final Field valueCacheField = SimpleAttributeResolver.class.getDeclaredField("valueCache");
      final Field attributeCacheField = SimpleAttributeResolver.class.getDeclaredField("attributeCache");
      valueCacheField.setAccessible(true);
      attributeCacheField.setAccessible(true);
      Object _get = valueCacheField.get(SimpleAttributeResolver.NAME_RESOLVER);
      final SimpleCache<?, ?> valueCache = ((SimpleCache<?, ?>) _get);
      Object _get_1 = attributeCacheField.get(SimpleAttributeResolver.NAME_RESOLVER);
      final SimpleCache<?, ?> attributeCache = ((SimpleCache<?, ?>) _get_1);
      valueCache.clear();
      attributeCache.clear();
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
  
  public static void eclipseCleanUp() {
    IWorkbench _workbench = PlatformUI.getWorkbench();
    final Workbench workbench = ((Workbench) _workbench);
    IEclipseContext _context = workbench.getContext();
    final EclipseContext context = ((EclipseContext) _context);
    context.cleanup();
  }
  
  public static void cleanWorkspace() {
    final Job job = new Job("cleanup workspace") {
      @Override
      protected IStatus run(final IProgressMonitor m) {
        try {
          IProject[] _projects = ResourcesPlugin.getWorkspace().getRoot().getProjects();
          for (final IProject p : _projects) {
            p.delete(true, m);
          }
          return Status.OK_STATUS;
        } catch (Throwable _e) {
          throw Exceptions.sneakyThrow(_e);
        }
      }
    };
    job.schedule();
    TestUtil.waitForJobs();
  }
  
  public static InputStream openFileFromPlugin(final String pluginName, final String pathInPlugin) {
    try {
      final Bundle bundle = Platform.getBundle(pluginName);
      final Path path = new Path(pathInPlugin);
      final InputStream stream = FileLocator.openStream(bundle, path, false);
      return stream;
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
  
  public static void copyFileFromPlugin(final String pluginName, final String pathInPlugin, final IFile targetFile, final IProgressMonitor m) {
    try {
      final InputStream stream = Util.openFileFromPlugin(pluginName, pathInPlugin);
      targetFile.create(stream, true, m);
      stream.close();
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
  
  private static long getGcCount() {
    long sum = 0;
    List<GarbageCollectorMXBean> _garbageCollectorMXBeans = ManagementFactory.getGarbageCollectorMXBeans();
    for (final GarbageCollectorMXBean b : _garbageCollectorMXBeans) {
      {
        long count = b.getCollectionCount();
        if ((count != (-1))) {
          long _sum = sum;
          sum = (_sum + count);
        }
      }
    }
    return sum;
  }
  
  public static long getCurrentlyUsedMemory() {
    long _used = ManagementFactory.getMemoryMXBean().getHeapMemoryUsage().getUsed();
    long _used_1 = ManagementFactory.getMemoryMXBean().getNonHeapMemoryUsage().getUsed();
    return (_used + _used_1);
  }
  
  public static void forceGc() {
    long before = Util.getGcCount();
    System.gc();
    while ((Util.getGcCount() == before)) {
    }
  }
  
  public static long getUsedMemory() {
    Util.forceGc();
    return Util.getCurrentlyUsedMemory();
  }
  
  public static void forceGcSettled() {
    try {
      long m2 = Util.getUsedMemory();
      do {
        {
          Thread.sleep(567);
          m2 = Util.getUsedMemory();
        }
      } while((m2 < Util.getUsedMemory()));
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
  
  public static long getSettledUsedMemory() {
    try {
      long m = 0;
      long m2 = Util.getUsedMemory();
      do {
        {
          Thread.sleep(567);
          m = m2;
          m2 = Util.getUsedMemory();
        }
      } while((m2 < Util.getUsedMemory()));
      return m;
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
  
  public static List<Long> getListMedian(final List<List<Long>> list) {
    final int length = list.get(0).size();
    final ArrayList<Long> result = CollectionLiterals.<Long>newArrayList();
    IntegerRange _upTo = new IntegerRange(0, (length - 1));
    for (final Integer i : _upTo) {
      {
        final ArrayList<Long> medianList = CollectionLiterals.<Long>newArrayList();
        int _size = list.size();
        int _minus = (_size - 1);
        IntegerRange _upTo_1 = new IntegerRange(0, _minus);
        for (final Integer j : _upTo_1) {
          medianList.add(list.get((j).intValue()).get((i).intValue()));
        }
        result.add(Util.median(medianList));
      }
    }
    return result;
  }
}
