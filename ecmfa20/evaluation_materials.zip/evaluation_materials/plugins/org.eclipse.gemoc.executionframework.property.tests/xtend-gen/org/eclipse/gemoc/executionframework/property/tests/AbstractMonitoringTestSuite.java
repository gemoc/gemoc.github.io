package org.eclipse.gemoc.executionframework.property.tests;

import com.google.common.base.Objects;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.gemoc.executionframework.engine.Activator;
import org.eclipse.gemoc.executionframework.property.tests.Util;
import org.eclipse.gemoc.xdsmlframework.api.core.EngineStatus;
import org.eclipse.gemoc.xdsmlframework.api.core.IExecutionEngine;
import org.eclipse.xtext.xbase.lib.Exceptions;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

@RunWith(Parameterized.class)
@SuppressWarnings("all")
public abstract class AbstractMonitoringTestSuite {
  protected String modelFileName;
  
  protected int propertyID = (-1);
  
  public abstract void genericInternalTest(final String plugin, final String folder, final String model, final int scenarioID);
  
  public abstract String getPluginName();
  
  public AbstractMonitoringTestSuite(final String modelFileName, final int propertyID) {
    this.modelFileName = modelFileName;
    this.propertyID = propertyID;
  }
  
  protected static Optional<String> findProperty(final String model, final String plugin, final String folder, final int propertyID) {
    try {
      Optional<String> _xifexpression = null;
      if ((propertyID > (-1))) {
        Optional<String> _xblockexpression = null;
        {
          final String fileExtension = model.substring(model.lastIndexOf("."));
          final String path = model.replace(fileExtension, "_properties.txt");
          final InputStream propertiesStream = Util.openFileFromPlugin(plugin, ((folder + "/") + path));
          InputStreamReader _inputStreamReader = new InputStreamReader(propertiesStream);
          final List<String> allProperties = new BufferedReader(_inputStreamReader).lines().collect(
            Collectors.<String>toList());
          propertiesStream.close();
          String _get = allProperties.get(propertyID);
          final String property = ((plugin + "/") + _get);
          _xblockexpression = Optional.<String>of(property);
        }
        _xifexpression = _xblockexpression;
      } else {
        return Optional.<String>empty();
      }
      return _xifexpression;
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
  
  @Test
  public void test() {
    this.genericInternalTest(this.getPluginName(), "/models", this.modelFileName, this.propertyID);
  }
  
  public static void gemocCleanUp() {
    final Function1<Map.Entry<String, IExecutionEngine<?>>, Boolean> _function = (Map.Entry<String, IExecutionEngine<?>> it) -> {
      EngineStatus.RunStatus _runningStatus = it.getValue().getRunningStatus();
      return Boolean.valueOf(Objects.equal(_runningStatus, EngineStatus.RunStatus.Stopped));
    };
    final Iterable<Map.Entry<String, IExecutionEngine<?>>> stoppedEnginesEntries = IterableExtensions.<Map.Entry<String, IExecutionEngine<?>>>filter(Activator.getDefault().gemocRunningEngineRegistry.getRunningEngines().entrySet(), _function);
    final HashSet<ResourceSet> resourceSets = new HashSet<ResourceSet>();
    for (final Map.Entry<String, IExecutionEngine<?>> stopped : stoppedEnginesEntries) {
      {
        final ResourceSet resourceSet = stopped.getValue().getExecutionContext().getResourceModel().getResourceSet();
        resourceSets.add(resourceSet);
        EList<Resource> _resources = resourceSet.getResources();
        for (final Resource resource : _resources) {
          {
            resource.eAdapters().clear();
            resource.unload();
          }
        }
        stopped.getValue().dispose();
        Activator.getDefault().gemocRunningEngineRegistry.unregisterEngine(stopped.getKey());
      }
    }
    for (final ResourceSet resourceSet : resourceSets) {
      resourceSet.getResources().clear();
    }
  }
}
