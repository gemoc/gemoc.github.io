package org.eclipse.gemoc.executionframework.property.tests.minijava;

import java.util.Collection;
import org.eclipse.gemoc.executionframework.property.tests.AbstractMonitoringTimeBenchmarkTestSuite;
import org.eclipse.gemoc.executionframework.property.tests.languages.MiniJava;
import org.eclipse.gemoc.executionframework.property.tests.minijava.MiniJavaTestData;
import org.eclipse.gemoc.executionframework.test.lib.ILanguageWrapper;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

@RunWith(Parameterized.class)
@SuppressWarnings("all")
public class MiniJavaMonitoringTimeBenchmarkingTest extends AbstractMonitoringTimeBenchmarkTestSuite {
  public MiniJavaMonitoringTimeBenchmarkingTest(final String model, final int scenarioID) {
    super(model, scenarioID);
  }
  
  @Parameterized.Parameters(name = "{0}[{1}]")
  public static Collection<Object[]> data() {
    return MiniJavaTestData.getData();
  }
  
  @Override
  public String getSemanticsPlugin() {
    return "org.tetrabox.minijava.xminijava";
  }
  
  @Override
  public ILanguageWrapper getDSL() {
    return new MiniJava();
  }
  
  @Override
  public String getPluginName() {
    return "org.tetrabox.minijava.property.benchmark";
  }
}
