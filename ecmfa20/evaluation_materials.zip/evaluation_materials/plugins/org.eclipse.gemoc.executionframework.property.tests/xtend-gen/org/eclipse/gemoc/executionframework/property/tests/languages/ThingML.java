package org.eclipse.gemoc.executionframework.property.tests.languages;

import org.eclipse.gemoc.executionframework.test.lib.ILanguageWrapper;

@SuppressWarnings("all")
public class ThingML implements ILanguageWrapper {
  @Override
  public String getEntryPoint() {
    return "public static void thingml.xthingml.aspects.AConfiguration.main(thingml.xthingml.thingML.Configuration)";
  }
  
  @Override
  public String getLanguageName() {
    return "thingml.XThingML";
  }
  
  @Override
  public String getInitializationMethod() {
    return "thingml.xthingml.aspects.AConfiguration.init";
  }
}
