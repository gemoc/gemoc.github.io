package org.eclipse.gemoc.executionframework.property.tests;

import java.lang.reflect.Field;
import org.eclipse.xtext.xbase.lib.Conversions;
import org.eclipse.xtext.xbase.lib.Exceptions;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.IterableExtensions;

@SuppressWarnings("all")
public class CSVLineTime {
  public String modelName = "";
  
  public String property = "";
  
  public int modelSize = (-1);
  
  public int amountSteps = (-1);
  
  public Long executionTime = Long.valueOf(0l);
  
  public Double variance = Double.valueOf(0.0);
  
  private final static String separator = ";";
  
  private static Iterable<Field> getAllFields() {
    final Function1<Field, Boolean> _function = (Field f) -> {
      boolean _contentEquals = f.getName().contentEquals("separator");
      return Boolean.valueOf((!_contentEquals));
    };
    return IterableExtensions.<Field>filter(((Iterable<Field>)Conversions.doWrapArray(CSVLineTime.class.getDeclaredFields())), _function);
  }
  
  public static String getColumnNames() {
    final Function1<Field, String> _function = (Field f) -> {
      return f.getName();
    };
    final Iterable<String> allNames = IterableExtensions.<Field, String>map(CSVLineTime.getAllFields(), _function);
    return IterableExtensions.join(allNames, CSVLineTime.separator);
  }
  
  public String customToString() {
    final Function1<Field, Object> _function = (Field f) -> {
      try {
        return f.get(this);
      } catch (Throwable _e) {
        throw Exceptions.sneakyThrow(_e);
      }
    };
    return IterableExtensions.join(IterableExtensions.<Field, Object>map(CSVLineTime.getAllFields(), _function), CSVLineTime.separator);
  }
}
