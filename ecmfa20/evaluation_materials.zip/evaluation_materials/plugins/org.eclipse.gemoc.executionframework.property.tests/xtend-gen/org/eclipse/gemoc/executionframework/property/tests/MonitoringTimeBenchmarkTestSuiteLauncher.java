package org.eclipse.gemoc.executionframework.property.tests;

import java.io.File;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.function.Consumer;
import org.eclipse.gemoc.executionframework.property.tests.TestData;
import org.eclipse.gemoc.executionframework.property.tests.utils.PDETestResultsCollector;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.xbase.lib.CollectionLiterals;
import org.eclipse.xtext.xbase.lib.Conversions;
import org.eclipse.xtext.xbase.lib.Exceptions;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.InputOutput;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

@RunWith(Parameterized.class)
@SuppressWarnings("all")
public class MonitoringTimeBenchmarkTestSuiteLauncher {
  @Parameterized.Parameters
  public static Collection<Object[]> data() {
    return TestData.getData();
  }
  
  @Parameterized.Parameter
  public String testClass;
  
  @Parameterized.Parameter(1)
  public String modelName;
  
  @Parameterized.Parameter(2)
  public int propertyId;
  
  @Rule
  public TemporaryFolder tmpFolderCreator = new TemporaryFolder();
  
  /**
   * Fill in the path to your Java home, gemoc launcher
   * (e.g. "/home/<username>/Downloads/gemoc-studio/plugins/org.eclipse.equinox.launcher_1.5.0.v20180512-1130.jar"),
   * path to the workspace containing the configuration for the test suite
   * (i.e. where you executed the BenchmarkSingleJVMTestSuite manually),
   * and the path where you want to write the output of the evaluation.
   */
  private final static int port = 7777;
  
  private final static String minMemory = "10g";
  
  private final static String maxMemory = "10g";
  
  private final static String javaHome = "/home/xp/jdk-10.0.2/bin/java";
  
  private final static String gemocPath = "/home/xp/Documents/gemoc-studio_monitoring/plugins/org.eclipse.equinox.launcher_1.5.0.v20180512-1130.jar";
  
  private final static String wsPath = "file:/home/xp/Documents/gemoc-studio_monitoring/junit-workspace";
  
  public static String prepareProperty(final String key, final String value) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("-D");
    _builder.append(key);
    _builder.append("=");
    _builder.append(value);
    return _builder.toString();
  }
  
  public void log(final String s) {
    InputOutput.<String>println(((((("### [" + this.modelName) + "_") + Integer.valueOf(this.propertyId)) + "] ") + s));
  }
  
  @Test
  public void test() {
    try {
      String _prepareProperty = MonitoringTimeBenchmarkTestSuiteLauncher.prepareProperty("modelNameProperty", this.modelName);
      String _prepareProperty_1 = MonitoringTimeBenchmarkTestSuiteLauncher.prepareProperty("propertyIdProperty", Integer.valueOf(this.propertyId).toString());
      String _string = Integer.valueOf(MonitoringTimeBenchmarkTestSuiteLauncher.port).toString();
      final List<String> params = Collections.<String>unmodifiableList(CollectionLiterals.<String>newArrayList(MonitoringTimeBenchmarkTestSuiteLauncher.javaHome, ("-Xms" + MonitoringTimeBenchmarkTestSuiteLauncher.minMemory), ("-Xmx" + MonitoringTimeBenchmarkTestSuiteLauncher.maxMemory), "-Declipse.pde.launch=true", "-Declipse.p2.data.area=@config.dir/p2", "--add-modules=ALL-SYSTEM", "-Dfile.encoding=UTF-8", _prepareProperty, _prepareProperty_1, "-classpath", "/home/xp/Documents/gemoc_studio-monitoring/plugins/org.eclipse.equinox.launcher_1.5.0.v20180512-1130.jar", "org.eclipse.equinox.launcher.Main", "-os", "linux", "-ws", "gtk", "-arch", "x86_64", "-nl", "fr_FR", "-consoleLog", "-version", "3", "-port", _string, "-testLoaderClass", "org.eclipse.jdt.internal.junit4.runner.JUnit4TestLoader", "-loaderpluginname", "org.eclipse.jdt.junit4.runtime", "-test", "org.eclipse.gemoc.executionframework.property.tests.ad.ActivityDiagramMonitoringTimeBenchmarkingTest:test", "-application", "org.eclipse.pde.junit.runtime.uitestapplication", "-product org.eclipse.platform.ide", "-testApplication", "org.eclipse.ui.ide.workbench", "-data", "/home/xp/Documents/gemoc_studio-monitoring/junit-workspace", "-configuration", "file:/home/xp/Documents/gemoc_studio-monitoring/workspace/.metadata/.plugins/org.eclipse.pde.core/pde-junit/", "-dev", "file:/home/xp/Documents/gemoc_studio-monitoring/workspace/.metadata/.plugins/org.eclipse.pde.core/pde-junit/dev.properties", "-os", "linux", "-ws", "gtk", "-arch", "x86_64", "-nl", "fr_FR", "-consoleLog", "-testpluginname", "org.eclipse.gemoc.executionframework.property.tests"));
      final PDETestResultsCollector collector = new PDETestResultsCollector("listening for measure");
      this.log("Start dummy junit listener");
      final Runnable junitListener = new Runnable() {
        @Override
        public void run() {
          try {
            collector.run(MonitoringTimeBenchmarkTestSuiteLauncher.port);
          } catch (Throwable _e) {
            throw Exceptions.sneakyThrow(_e);
          }
        }
      };
      final Thread junitListenerThread = new Thread(junitListener);
      junitListenerThread.start();
      this.log("Start test in dedicated JVM");
      final File f = new File("/home/xp/Documents/gemoc_studio-monitoring/junit-workspace/.metadata/.plugins/org.eclipse.core.resources");
      final Function1<File, Boolean> _function = (File s) -> {
        return Boolean.valueOf(s.getName().endsWith(".snap"));
      };
      final Consumer<File> _function_1 = (File s) -> {
        s.delete();
      };
      IterableExtensions.<File>filter(((Iterable<File>)Conversions.doWrapArray(f.listFiles())), _function).forEach(_function_1);
      final ProcessBuilder processBuilder = new ProcessBuilder(params);
      final Process process = processBuilder.inheritIO().start();
      process.waitFor();
      this.log("Kill dummy junit listener");
      junitListenerThread.stop();
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
}
