package org.eclipse.gemoc.executionframework.property.tests.minijava;

import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.xbase.lib.InputOutput;
import org.eclipse.xtext.xbase.lib.IntegerRange;

@SuppressWarnings("all")
public class ModelGenerator {
  public static void main(final String[] args) {
    InputOutput.<String>println(ModelGenerator.generateModel(1000, 1));
  }
  
  public static String generateScopes(final int size) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("package minijava.queries");
    _builder.newLine();
    _builder.newLine();
    _builder.append("import \"http://org.tetrabox.minijava.xminijava/miniJava/\"");
    _builder.newLine();
    _builder.newLine();
    _builder.append("pattern miniJavaBeforeScope() {");
    _builder.newLine();
    {
      IntegerRange _upTo = new IntegerRange(0, size);
      for(final Integer i : _upTo) {
        _builder.append("\t");
        _builder.append("find miniJavaScopeIntegerValue(0, \"beforeVar_");
        _builder.append(i, "\t");
        _builder.append("\");");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("}");
    _builder.newLine();
    _builder.newLine();
    _builder.append("pattern miniJavaAfterScope() {");
    _builder.newLine();
    {
      IntegerRange _upTo_1 = new IntegerRange(0, size);
      for(final Integer i_1 : _upTo_1) {
        _builder.append("\t");
        _builder.append("find miniJavaScopeIntegerValue(0, \"afterVar_");
        _builder.append(i_1, "\t");
        _builder.append("\");");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("}");
    _builder.newLine();
    _builder.newLine();
    _builder.append("pattern miniJavaBetween1Scope() {");
    _builder.newLine();
    {
      IntegerRange _upTo_2 = new IntegerRange(0, size);
      for(final Integer i_2 : _upTo_2) {
        _builder.append("\t");
        _builder.append("find miniJavaScopeIntegerValue(0, \"betweenVar1_");
        _builder.append(i_2, "\t");
        _builder.append("\");");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("}");
    _builder.newLine();
    _builder.newLine();
    _builder.append("pattern miniJavaBetween2Scope() {");
    _builder.newLine();
    {
      IntegerRange _upTo_3 = new IntegerRange(0, size);
      for(final Integer i_3 : _upTo_3) {
        _builder.append("\t");
        _builder.append("find miniJavaScopeIntegerValue(5, \"betweenVar2_");
        _builder.append(i_3, "\t");
        _builder.append("\");");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("}");
    _builder.newLine();
    _builder.newLine();
    _builder.append("pattern miniJavaAfterUntil1Scope() {");
    _builder.newLine();
    {
      IntegerRange _upTo_4 = new IntegerRange(0, size);
      for(final Integer i_4 : _upTo_4) {
        _builder.append("\t");
        _builder.append("find miniJavaScopeIntegerValue(0, \"afterUntilVar1_");
        _builder.append(i_4, "\t");
        _builder.append("\");");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("}");
    _builder.newLine();
    _builder.newLine();
    _builder.append("pattern miniJavaAfterUntil2Scope() {");
    _builder.newLine();
    {
      IntegerRange _upTo_5 = new IntegerRange(0, size);
      for(final Integer i_5 : _upTo_5) {
        _builder.append("\t");
        _builder.append("find miniJavaScopeIntegerValue(5, \"afterUntilVar2_");
        _builder.append(i_5, "\t");
        _builder.append("\");");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("}");
    _builder.newLine();
    _builder.newLine();
    _builder.append("pattern miniJavaScopeIntegerValue(iVal: java Integer, sVal: java String) {");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("SymbolBinding.symbol(someBinding, someSymbol);");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("SymbolBinding.value(someBinding, someValue);");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("Symbol.name(someSymbol, sVal);");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("IntegerValue.value(someValue, iVal);");
    _builder.newLine();
    _builder.append("}");
    _builder.newLine();
    return _builder.toString();
  }
  
  public static String generatePatterns(final int size) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("package minijava.queries");
    _builder.newLine();
    _builder.newLine();
    _builder.append("import \"http://org.tetrabox.minijava.xminijava/miniJava/\"");
    _builder.newLine();
    _builder.newLine();
    _builder.append("pattern miniJavaAlwaysPattern() {");
    _builder.newLine();
    {
      IntegerRange _upTo = new IntegerRange(0, size);
      for(final Integer i : _upTo) {
        _builder.append("\t");
        _builder.append("neg find miniJavaPatternIntegerValue(10, \"alwaysVar_");
        _builder.append(i, "\t");
        _builder.append("\");");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("}");
    _builder.newLine();
    _builder.newLine();
    _builder.append("pattern miniJavaExistsPattern() {");
    _builder.newLine();
    {
      IntegerRange _upTo_1 = new IntegerRange(0, size);
      for(final Integer i_1 : _upTo_1) {
        _builder.append("\t");
        _builder.append("find miniJavaPatternIntegerValue(3, \"existsVar_");
        _builder.append(i_1, "\t");
        _builder.append("\");");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("}");
    _builder.newLine();
    _builder.newLine();
    _builder.append("pattern miniJavaNeverPattern() {");
    _builder.newLine();
    {
      IntegerRange _upTo_2 = new IntegerRange(0, size);
      for(final Integer i_2 : _upTo_2) {
        _builder.append("\t");
        _builder.append("find miniJavaPatternIntegerValue(10, \"neverVar_");
        _builder.append(i_2, "\t");
        _builder.append("\");");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("}");
    _builder.newLine();
    _builder.newLine();
    _builder.append("pattern miniJavaPrecedence1Pattern() {");
    _builder.newLine();
    {
      IntegerRange _upTo_3 = new IntegerRange(0, size);
      for(final Integer i_3 : _upTo_3) {
        _builder.append("\t");
        _builder.append("find miniJavaPatternIntegerValue(1, \"precedenceVar1_");
        _builder.append(i_3, "\t");
        _builder.append("\");");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("}");
    _builder.newLine();
    _builder.newLine();
    _builder.append("pattern miniJavaPrecedence2Pattern() {");
    _builder.newLine();
    {
      IntegerRange _upTo_4 = new IntegerRange(0, size);
      for(final Integer i_4 : _upTo_4) {
        _builder.append("\t");
        _builder.append("find miniJavaPatternIntegerValue(4, \"precedenceVar2_");
        _builder.append(i_4, "\t");
        _builder.append("\");");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("}");
    _builder.newLine();
    _builder.newLine();
    _builder.append("pattern miniJavaResponse1Pattern() {");
    _builder.newLine();
    {
      IntegerRange _upTo_5 = new IntegerRange(0, size);
      for(final Integer i_5 : _upTo_5) {
        _builder.append("\t");
        _builder.append("find miniJavaPatternIntegerValue(1, \"responseVar1_");
        _builder.append(i_5, "\t");
        _builder.append("\");");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("}");
    _builder.newLine();
    _builder.newLine();
    _builder.append("pattern miniJavaResponse2Pattern() {");
    _builder.newLine();
    {
      IntegerRange _upTo_6 = new IntegerRange(0, size);
      for(final Integer i_6 : _upTo_6) {
        _builder.append("\t");
        _builder.append("find miniJavaPatternIntegerValue(4, \"responseVar2_");
        _builder.append(i_6, "\t");
        _builder.append("\");");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("}");
    _builder.newLine();
    _builder.newLine();
    _builder.append("pattern miniJavaPrecedence3Pattern() {");
    _builder.newLine();
    {
      IntegerRange _upTo_7 = new IntegerRange(0, size);
      for(final Integer i_7 : _upTo_7) {
        _builder.append("\t");
        _builder.append("find miniJavaPatternIntegerValue(0, \"precedenceVar3_");
        _builder.append(i_7, "\t");
        _builder.append("\");");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("}");
    _builder.newLine();
    _builder.newLine();
    _builder.append("pattern miniJavaPrecedence4Pattern() {");
    _builder.newLine();
    {
      IntegerRange _upTo_8 = new IntegerRange(0, size);
      for(final Integer i_8 : _upTo_8) {
        _builder.append("\t");
        _builder.append("find miniJavaPatternIntegerValue(0, \"precedenceVar4_");
        _builder.append(i_8, "\t");
        _builder.append("\");");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("}");
    _builder.newLine();
    _builder.newLine();
    _builder.append("pattern miniJavaPatternIntegerValue(iVal: java Integer, sVal: java String) {");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("SymbolBinding.symbol(someBinding, someSymbol);");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("SymbolBinding.value(someBinding, someValue);");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("Symbol.name(someSymbol, sVal);");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("IntegerValue.value(someValue, iVal);");
    _builder.newLine();
    _builder.append("}");
    _builder.newLine();
    return _builder.toString();
  }
  
  public static String generateModel(final int time, final int size) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("package minijava.samples;");
    _builder.newLine();
    _builder.newLine();
    _builder.append("public class HelloWorld {");
    _builder.newLine();
    _builder.newLine();
    _builder.append("    ");
    _builder.append("public static void main(String[] args) {");
    _builder.newLine();
    {
      IntegerRange _upTo = new IntegerRange(0, size);
      for(final Integer i : _upTo) {
        _builder.append("        ");
        _builder.append("int alwaysVar_");
        _builder.append(i, "        ");
        _builder.append(" = 0;");
        _builder.newLineIfNotEmpty();
      }
    }
    {
      IntegerRange _upTo_1 = new IntegerRange(0, size);
      for(final Integer i_1 : _upTo_1) {
        _builder.append("        ");
        _builder.append("int existsVar_");
        _builder.append(i_1, "        ");
        _builder.append(" = 0;");
        _builder.newLineIfNotEmpty();
      }
    }
    {
      IntegerRange _upTo_2 = new IntegerRange(0, size);
      for(final Integer i_2 : _upTo_2) {
        _builder.append("\t\t");
        _builder.append("int absenceVar_");
        _builder.append(i_2, "\t\t");
        _builder.append(" = 0;");
        _builder.newLineIfNotEmpty();
      }
    }
    {
      IntegerRange _upTo_3 = new IntegerRange(0, size);
      for(final Integer i_3 : _upTo_3) {
        _builder.append("\t\t");
        _builder.append("int precedenceVar1_");
        _builder.append(i_3, "\t\t");
        _builder.append(" = 0;");
        _builder.newLineIfNotEmpty();
      }
    }
    {
      IntegerRange _upTo_4 = new IntegerRange(0, size);
      for(final Integer i_4 : _upTo_4) {
        _builder.append("\t\t");
        _builder.append("int precedenceVar2_");
        _builder.append(i_4, "\t\t");
        _builder.append(" = 0;");
        _builder.newLineIfNotEmpty();
      }
    }
    {
      IntegerRange _upTo_5 = new IntegerRange(0, size);
      for(final Integer i_5 : _upTo_5) {
        _builder.append("\t\t");
        _builder.append("int precedenceVar3_");
        _builder.append(i_5, "\t\t");
        _builder.append(" = -91;");
        _builder.newLineIfNotEmpty();
      }
    }
    {
      IntegerRange _upTo_6 = new IntegerRange(0, size);
      for(final Integer i_6 : _upTo_6) {
        _builder.append("\t\t");
        _builder.append("int precedenceVar4_");
        _builder.append(i_6, "\t\t");
        _builder.append(" = -93;");
        _builder.newLineIfNotEmpty();
      }
    }
    {
      IntegerRange _upTo_7 = new IntegerRange(0, size);
      for(final Integer i_7 : _upTo_7) {
        _builder.append("\t\t");
        _builder.append("int responseVar1_");
        _builder.append(i_7, "\t\t");
        _builder.append(" = 0;");
        _builder.newLineIfNotEmpty();
      }
    }
    {
      IntegerRange _upTo_8 = new IntegerRange(0, size);
      for(final Integer i_8 : _upTo_8) {
        _builder.append("\t\t");
        _builder.append("int responseVar2_");
        _builder.append(i_8, "\t\t");
        _builder.append(" = 0;");
        _builder.newLineIfNotEmpty();
      }
    }
    {
      IntegerRange _upTo_9 = new IntegerRange(0, size);
      for(final Integer i_9 : _upTo_9) {
        _builder.append("\t\t");
        _builder.append("int afterVar_");
        _builder.append(i_9, "\t\t");
        _builder.append(" = -50;");
        _builder.newLineIfNotEmpty();
      }
    }
    {
      IntegerRange _upTo_10 = new IntegerRange(0, size);
      for(final Integer i_10 : _upTo_10) {
        _builder.append("\t\t");
        _builder.append("int beforeVar_");
        _builder.append(i_10, "\t\t");
        _builder.append(" = -95;");
        _builder.newLineIfNotEmpty();
      }
    }
    {
      IntegerRange _upTo_11 = new IntegerRange(0, size);
      for(final Integer i_11 : _upTo_11) {
        _builder.append("\t\t");
        _builder.append("int betweenVar1_");
        _builder.append(i_11, "\t\t");
        _builder.append(" = 0;");
        _builder.newLineIfNotEmpty();
      }
    }
    {
      IntegerRange _upTo_12 = new IntegerRange(0, size);
      for(final Integer i_12 : _upTo_12) {
        _builder.append("\t\t");
        _builder.append("int betweenVar2_");
        _builder.append(i_12, "\t\t");
        _builder.append(" = 0;");
        _builder.newLineIfNotEmpty();
      }
    }
    {
      IntegerRange _upTo_13 = new IntegerRange(0, size);
      for(final Integer i_13 : _upTo_13) {
        _builder.append("\t\t");
        _builder.append("int afterUntilVar1_");
        _builder.append(i_13, "\t\t");
        _builder.append(" = 0;");
        _builder.newLineIfNotEmpty();
      }
    }
    {
      IntegerRange _upTo_14 = new IntegerRange(0, size);
      for(final Integer i_14 : _upTo_14) {
        _builder.append("        ");
        _builder.append("int afterUntilVar2_");
        _builder.append(i_14, "        ");
        _builder.append(" = 0;");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("        ");
    _builder.append("for (int j = 0; j < ");
    _builder.append(time, "        ");
    _builder.append("; j = j + 1) {");
    _builder.newLineIfNotEmpty();
    {
      IntegerRange _upTo_15 = new IntegerRange(0, size);
      for(final Integer i_15 : _upTo_15) {
        _builder.append("\t        ");
        _builder.append("alwaysVar_");
        _builder.append(i_15, "\t        ");
        _builder.append(" = j % 10;");
        _builder.newLineIfNotEmpty();
      }
    }
    {
      IntegerRange _upTo_16 = new IntegerRange(0, size);
      for(final Integer i_16 : _upTo_16) {
        _builder.append("\t        ");
        _builder.append("existsVar_");
        _builder.append(i_16, "\t        ");
        _builder.append(" = j % 10;");
        _builder.newLineIfNotEmpty();
      }
    }
    {
      IntegerRange _upTo_17 = new IntegerRange(0, size);
      for(final Integer i_17 : _upTo_17) {
        _builder.append("\t        ");
        _builder.append("absenceVar_");
        _builder.append(i_17, "\t        ");
        _builder.append(" = j % 10;");
        _builder.newLineIfNotEmpty();
      }
    }
    {
      IntegerRange _upTo_18 = new IntegerRange(0, size);
      for(final Integer i_18 : _upTo_18) {
        _builder.append("\t        ");
        _builder.append("precedenceVar1_");
        _builder.append(i_18, "\t        ");
        _builder.append(" = j % 10;");
        _builder.newLineIfNotEmpty();
      }
    }
    {
      IntegerRange _upTo_19 = new IntegerRange(0, size);
      for(final Integer i_19 : _upTo_19) {
        _builder.append("\t        ");
        _builder.append("precedenceVar2_");
        _builder.append(i_19, "\t        ");
        _builder.append(" = j % 10;");
        _builder.newLineIfNotEmpty();
      }
    }
    {
      IntegerRange _upTo_20 = new IntegerRange(0, size);
      for(final Integer i_20 : _upTo_20) {
        _builder.append("\t        ");
        _builder.append("precedenceVar3_");
        _builder.append(i_20, "\t        ");
        _builder.append(" = precedenceVar3_");
        _builder.append(i_20, "\t        ");
        _builder.append(" + 1;");
        _builder.newLineIfNotEmpty();
      }
    }
    {
      IntegerRange _upTo_21 = new IntegerRange(0, size);
      for(final Integer i_21 : _upTo_21) {
        _builder.append("\t        ");
        _builder.append("precedenceVar4_");
        _builder.append(i_21, "\t        ");
        _builder.append(" = precedenceVar4_");
        _builder.append(i_21, "\t        ");
        _builder.append(" + 1;");
        _builder.newLineIfNotEmpty();
      }
    }
    {
      IntegerRange _upTo_22 = new IntegerRange(0, size);
      for(final Integer i_22 : _upTo_22) {
        _builder.append("\t        ");
        _builder.append("responseVar1_");
        _builder.append(i_22, "\t        ");
        _builder.append(" = j % 10;");
        _builder.newLineIfNotEmpty();
      }
    }
    {
      IntegerRange _upTo_23 = new IntegerRange(0, size);
      for(final Integer i_23 : _upTo_23) {
        _builder.append("\t        ");
        _builder.append("responseVar2_");
        _builder.append(i_23, "\t        ");
        _builder.append(" = j % 10;");
        _builder.newLineIfNotEmpty();
      }
    }
    {
      IntegerRange _upTo_24 = new IntegerRange(0, size);
      for(final Integer i_24 : _upTo_24) {
        _builder.append("\t        ");
        _builder.append("afterVar_");
        _builder.append(i_24, "\t        ");
        _builder.append(" = afterVar_");
        _builder.append(i_24, "\t        ");
        _builder.append(" + 1;");
        _builder.newLineIfNotEmpty();
      }
    }
    {
      IntegerRange _upTo_25 = new IntegerRange(0, size);
      for(final Integer i_25 : _upTo_25) {
        _builder.append("\t        ");
        _builder.append("beforeVar_");
        _builder.append(i_25, "\t        ");
        _builder.append(" = beforeVar_");
        _builder.append(i_25, "\t        ");
        _builder.append(" + 1;");
        _builder.newLineIfNotEmpty();
      }
    }
    {
      IntegerRange _upTo_26 = new IntegerRange(0, size);
      for(final Integer i_26 : _upTo_26) {
        _builder.append("\t        ");
        _builder.append("betweenVar1_");
        _builder.append(i_26, "\t        ");
        _builder.append(" = j % 10;");
        _builder.newLineIfNotEmpty();
      }
    }
    {
      IntegerRange _upTo_27 = new IntegerRange(0, size);
      for(final Integer i_27 : _upTo_27) {
        _builder.append("\t        ");
        _builder.append("betweenVar2_");
        _builder.append(i_27, "\t        ");
        _builder.append(" = j % 10;");
        _builder.newLineIfNotEmpty();
      }
    }
    {
      IntegerRange _upTo_28 = new IntegerRange(0, size);
      for(final Integer i_28 : _upTo_28) {
        _builder.append("\t        ");
        _builder.append("afterUntilVar1_");
        _builder.append(i_28, "\t        ");
        _builder.append(" = j % 10;");
        _builder.newLineIfNotEmpty();
      }
    }
    {
      IntegerRange _upTo_29 = new IntegerRange(0, size);
      for(final Integer i_29 : _upTo_29) {
        _builder.append("\t        ");
        _builder.append("afterUntilVar2_");
        _builder.append(i_29, "\t        ");
        _builder.append(" = j % 10;");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("        \t");
    _builder.newLine();
    _builder.append("        \t");
    _builder.append("System.out.println(\"j=\"+j);");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("}");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("}");
    _builder.newLine();
    _builder.append("}");
    _builder.newLine();
    return _builder.toString();
  }
}
