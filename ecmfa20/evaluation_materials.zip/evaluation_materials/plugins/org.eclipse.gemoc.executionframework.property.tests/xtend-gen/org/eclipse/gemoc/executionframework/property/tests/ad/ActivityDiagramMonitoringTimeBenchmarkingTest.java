package org.eclipse.gemoc.executionframework.property.tests.ad;

import java.util.Collection;
import org.eclipse.gemoc.executionframework.property.tests.AbstractMonitoringTimeBenchmarkTestSuite;
import org.eclipse.gemoc.executionframework.property.tests.ad.ActivityDiagramTestData;
import org.eclipse.gemoc.executionframework.property.tests.languages.ActivityDiagram;
import org.eclipse.gemoc.executionframework.test.lib.ILanguageWrapper;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

@RunWith(Parameterized.class)
@SuppressWarnings("all")
public class ActivityDiagramMonitoringTimeBenchmarkingTest extends AbstractMonitoringTimeBenchmarkTestSuite {
  public ActivityDiagramMonitoringTimeBenchmarkingTest(final String model, final int scenarioID) {
    super(model, scenarioID);
  }
  
  @Parameterized.Parameters(name = "{0}[{1}]")
  public static Collection<Object[]> data() {
    return ActivityDiagramTestData.getData();
  }
  
  @Override
  public String getSemanticsPlugin() {
    return "org.eclipse.gemoc.activitydiagram.sequential.k3dsa";
  }
  
  @Override
  public ILanguageWrapper getDSL() {
    return new ActivityDiagram();
  }
  
  @Override
  public String getPluginName() {
    return "org.eclipse.gemoc.activitydiagram.sequential.property.benchmark";
  }
}
