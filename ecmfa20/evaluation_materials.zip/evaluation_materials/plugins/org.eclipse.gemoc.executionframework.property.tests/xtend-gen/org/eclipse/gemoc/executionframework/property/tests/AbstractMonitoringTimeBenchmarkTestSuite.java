package org.eclipse.gemoc.executionframework.property.tests;

import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import org.eclipse.gemoc.execution.sequential.javaengine.tests.wrapper.JavaEngineWrapper;
import org.eclipse.gemoc.executionframework.property.monitor.manager.PropertyManager;
import org.eclipse.gemoc.executionframework.property.tests.AbstractMonitoringTestSuite;
import org.eclipse.gemoc.executionframework.property.tests.CSVLineTime;
import org.eclipse.gemoc.executionframework.property.tests.Util;
import org.eclipse.gemoc.executionframework.test.lib.IEngineWrapper;
import org.eclipse.gemoc.executionframework.test.lib.IExecutableModel;
import org.eclipse.gemoc.executionframework.test.lib.ILanguageWrapper;
import org.eclipse.gemoc.executionframework.test.lib.impl.TestHelper;
import org.eclipse.gemoc.executionframework.test.lib.impl.TestModel;
import org.eclipse.gemoc.xdsmlframework.api.engine_addon.IEngineAddon;
import org.eclipse.xtend.lib.annotations.Data;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.xbase.lib.CollectionLiterals;
import org.eclipse.xtext.xbase.lib.Conversions;
import org.eclipse.xtext.xbase.lib.Exceptions;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.InputOutput;
import org.eclipse.xtext.xbase.lib.IntegerRange;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.eclipse.xtext.xbase.lib.ListExtensions;
import org.eclipse.xtext.xbase.lib.Pure;
import org.eclipse.xtext.xbase.lib.util.ToStringBuilder;
import org.junit.AfterClass;
import org.junit.BeforeClass;

@SuppressWarnings("all")
public abstract class AbstractMonitoringTimeBenchmarkTestSuite extends AbstractMonitoringTestSuite {
  @Data
  public static class BenchResult1 {
    private final int amountSteps;
    
    private final List<Long> executionTimes;
    
    public BenchResult1(final int amountSteps, final List<Long> executionTimes) {
      super();
      this.amountSteps = amountSteps;
      this.executionTimes = executionTimes;
    }
    
    @Override
    @Pure
    public int hashCode() {
      final int prime = 31;
      int result = 1;
      result = prime * result + this.amountSteps;
      return prime * result + ((this.executionTimes== null) ? 0 : this.executionTimes.hashCode());
    }
    
    @Override
    @Pure
    public boolean equals(final Object obj) {
      if (this == obj)
        return true;
      if (obj == null)
        return false;
      if (getClass() != obj.getClass())
        return false;
      AbstractMonitoringTimeBenchmarkTestSuite.BenchResult1 other = (AbstractMonitoringTimeBenchmarkTestSuite.BenchResult1) obj;
      if (other.amountSteps != this.amountSteps)
        return false;
      if (this.executionTimes == null) {
        if (other.executionTimes != null)
          return false;
      } else if (!this.executionTimes.equals(other.executionTimes))
        return false;
      return true;
    }
    
    @Override
    @Pure
    public String toString() {
      ToStringBuilder b = new ToStringBuilder(this);
      b.add("amountSteps", this.amountSteps);
      b.add("executionTimes", this.executionTimes);
      return b.toString();
    }
    
    @Pure
    public int getAmountSteps() {
      return this.amountSteps;
    }
    
    @Pure
    public List<Long> getExecutionTimes() {
      return this.executionTimes;
    }
  }
  
  @Data
  public static class BenchResult2 {
    private final int amountSteps;
    
    private final Long executionTime;
    
    private final Double variance;
    
    public BenchResult2(final int amountSteps, final Long executionTime, final Double variance) {
      super();
      this.amountSteps = amountSteps;
      this.executionTime = executionTime;
      this.variance = variance;
    }
    
    @Override
    @Pure
    public int hashCode() {
      final int prime = 31;
      int result = 1;
      result = prime * result + this.amountSteps;
      result = prime * result + ((this.executionTime== null) ? 0 : this.executionTime.hashCode());
      return prime * result + ((this.variance== null) ? 0 : this.variance.hashCode());
    }
    
    @Override
    @Pure
    public boolean equals(final Object obj) {
      if (this == obj)
        return true;
      if (obj == null)
        return false;
      if (getClass() != obj.getClass())
        return false;
      AbstractMonitoringTimeBenchmarkTestSuite.BenchResult2 other = (AbstractMonitoringTimeBenchmarkTestSuite.BenchResult2) obj;
      if (other.amountSteps != this.amountSteps)
        return false;
      if (this.executionTime == null) {
        if (other.executionTime != null)
          return false;
      } else if (!this.executionTime.equals(other.executionTime))
        return false;
      if (this.variance == null) {
        if (other.variance != null)
          return false;
      } else if (!this.variance.equals(other.variance))
        return false;
      return true;
    }
    
    @Override
    @Pure
    public String toString() {
      ToStringBuilder b = new ToStringBuilder(this);
      b.add("amountSteps", this.amountSteps);
      b.add("executionTime", this.executionTime);
      b.add("variance", this.variance);
      return b.toString();
    }
    
    @Pure
    public int getAmountSteps() {
      return this.amountSteps;
    }
    
    @Pure
    public Long getExecutionTime() {
      return this.executionTime;
    }
    
    @Pure
    public Double getVariance() {
      return this.variance;
    }
  }
  
  private static File outputFolder;
  
  private static File outputCSV;
  
  private static PrintWriter outputCSVWriter;
  
  private static FileOutputStream outputCSVStream;
  
  public abstract String getSemanticsPlugin();
  
  @BeforeClass
  public static void before() {
    try {
      final Calendar currentDate = Calendar.getInstance();
      final SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-YYYY_HH-mm-ss");
      final String dateNow = formatter.format(currentDate.getTime());
      File _file = new File((("output_time" + "_") + dateNow));
      AbstractMonitoringTimeBenchmarkTestSuite.outputFolder = _file;
      boolean _exists = AbstractMonitoringTimeBenchmarkTestSuite.outputFolder.exists();
      boolean _not = (!_exists);
      if (_not) {
        AbstractMonitoringTimeBenchmarkTestSuite.outputFolder.mkdir();
      }
      File _file_1 = new File(AbstractMonitoringTimeBenchmarkTestSuite.outputFolder, "resultsTime.csv");
      AbstractMonitoringTimeBenchmarkTestSuite.outputCSV = _file_1;
      FileOutputStream _fileOutputStream = new FileOutputStream(AbstractMonitoringTimeBenchmarkTestSuite.outputCSV);
      AbstractMonitoringTimeBenchmarkTestSuite.outputCSVStream = _fileOutputStream;
      PrintWriter _printWriter = new PrintWriter(AbstractMonitoringTimeBenchmarkTestSuite.outputCSVStream, true);
      AbstractMonitoringTimeBenchmarkTestSuite.outputCSVWriter = _printWriter;
      AbstractMonitoringTimeBenchmarkTestSuite.outputCSVWriter.println(CSVLineTime.getColumnNames());
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
  
  @AfterClass
  public static void after() {
    try {
      AbstractMonitoringTimeBenchmarkTestSuite.outputCSVStream.close();
      AbstractMonitoringTimeBenchmarkTestSuite.outputCSVWriter.close();
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
  
  public AbstractMonitoringTimeBenchmarkTestSuite(final String model, final int scenarioID) {
    super(model, scenarioID);
  }
  
  public AbstractMonitoringTimeBenchmarkTestSuite.BenchResult1 runBench(final IEngineWrapper engine, final ILanguageWrapper language, final IExecutableModel model, final String propertyFilepath) {
    final ArrayList<Long> executionTimes = new ArrayList<Long>();
    boolean haveAmounts = false;
    int amountSteps = 0;
    Set<IEngineAddon> _xifexpression = null;
    if (((propertyFilepath != null) && (!propertyFilepath.isEmpty()))) {
      Set<IEngineAddon> _xblockexpression = null;
      {
        final PropertyManager propertyManager = new PropertyManager();
        propertyManager.addProperty(propertyFilepath, true);
        _xblockexpression = Collections.<IEngineAddon>unmodifiableSet(CollectionLiterals.<IEngineAddon>newHashSet(propertyManager));
      }
      _xifexpression = _xblockexpression;
    } else {
      _xifexpression = Collections.<IEngineAddon>unmodifiableSet(CollectionLiterals.<IEngineAddon>newHashSet());
    }
    final Set<IEngineAddon> addons = _xifexpression;
    IntegerRange _upTo = new IntegerRange(1, 30);
    for (final Integer x : _upTo) {
      {
        final TestHelper.TestResult testResult = TestHelper.testWithJob(engine, language, Collections.<String>unmodifiableSet(CollectionLiterals.<String>newHashSet()), addons, model, true);
        executionTimes.add(Long.valueOf(testResult.executionDuration));
        if ((!haveAmounts)) {
          amountSteps = testResult.amountOfStepsExecuted;
          haveAmounts = true;
        }
        Util.cleanup(this.getSemanticsPlugin());
      }
    }
    int _size = executionTimes.size();
    int _minus = (_size - 11);
    List<Long> _subList = executionTimes.subList(_minus, executionTimes.size());
    return new AbstractMonitoringTimeBenchmarkTestSuite.BenchResult1(amountSteps, _subList);
  }
  
  public AbstractMonitoringTimeBenchmarkTestSuite.BenchResult2 testGeneric(final String name, final IEngineWrapper engine, final ILanguageWrapper language, final String plugin, final String folder, final String model, final String propertyFilepath) {
    TestModel _testModel = new TestModel(plugin, folder, model, "", "");
    final AbstractMonitoringTimeBenchmarkTestSuite.BenchResult1 result1 = this.runBench(engine, language, _testModel, propertyFilepath);
    final List<Long> numbers = result1.executionTimes;
    final Long mean = Util.mean(numbers);
    final Function1<Long, Double> _function = (Long n) -> {
      return Double.valueOf(((0.000001 * ((n).longValue() - (mean).longValue())) * (0.000001 * ((n).longValue() - (mean).longValue()))));
    };
    final Double variance = Util.meanDouble(ListExtensions.<Long, Double>map(numbers, _function));
    StringConcatenation _builder = new StringConcatenation();
    _builder.append(name);
    _builder.append(" - ");
    _builder.append(model);
    _builder.append(" - scenario ");
    _builder.append(this.propertyID);
    _builder.append(" :");
    InputOutput.<String>println(_builder.toString());
    InputOutput.<String>println(("- numbers: " + numbers));
    InputOutput.<String>println(("- mean: " + mean));
    InputOutput.<String>println(("- variance: " + variance));
    return new AbstractMonitoringTimeBenchmarkTestSuite.BenchResult2(result1.amountSteps, mean, variance);
  }
  
  public abstract ILanguageWrapper getDSL();
  
  public AbstractMonitoringTimeBenchmarkTestSuite.BenchResult2 testMonitoring(final String plugin, final String folder, final String model, final String propertyFilepath) {
    final JavaEngineWrapper engine = new JavaEngineWrapper();
    return this.testGeneric("monitoring", engine, this.getDSL(), plugin, folder, model, propertyFilepath);
  }
  
  @Override
  public void genericInternalTest(final String plugin, final String folder, final String model, final int propertyID) {
    if ((propertyID > (-2))) {
      final CSVLineTime line = new CSVLineTime();
      line.modelName = model;
      final Function1<String, Boolean> _function = (String s) -> {
        return Boolean.valueOf((s.startsWith("x") || s.endsWith("c")));
      };
      line.modelSize = Integer.parseInt(IterableExtensions.<String>findFirst(((Iterable<String>)Conversions.doWrapArray(model.split("_"))), _function).replace("x", "").replace("c", ""));
      final String propertyFilepath = AbstractMonitoringTestSuite.findProperty(model, plugin, folder, propertyID).orElse("");
      line.property = IterableExtensions.<String>head(((Iterable<String>)Conversions.doWrapArray(IterableExtensions.<String>last(((Iterable<String>)Conversions.doWrapArray(propertyFilepath.split("/")))).split("\\."))));
      final AbstractMonitoringTimeBenchmarkTestSuite.BenchResult2 resultMonitoring = this.testMonitoring(plugin, folder, model, propertyFilepath);
      line.executionTime = resultMonitoring.executionTime;
      line.variance = resultMonitoring.variance;
      line.amountSteps = resultMonitoring.getAmountSteps();
      AbstractMonitoringTimeBenchmarkTestSuite.outputCSVWriter.println(line.customToString());
    } else {
      this.testMonitoring(plugin, folder, model, "");
    }
  }
}
