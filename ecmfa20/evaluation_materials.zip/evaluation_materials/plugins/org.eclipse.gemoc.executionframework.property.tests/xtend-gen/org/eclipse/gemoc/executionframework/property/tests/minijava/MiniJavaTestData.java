package org.eclipse.gemoc.executionframework.property.tests.minijava;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import org.eclipse.gemoc.executionframework.property.tests.TestData;
import org.eclipse.xtext.xbase.lib.CollectionLiterals;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.IntegerRange;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.eclipse.xtext.xbase.lib.Pair;

@SuppressWarnings("all")
public class MiniJavaTestData extends TestData {
  public static Collection<Object[]> getData() {
    final ArrayList<Object[]> result = new ArrayList<Object[]>();
    if ((((TestData.modelNameProperty != null) && (!TestData.modelNameProperty.isEmpty())) && ((TestData.propertyIdProperty != null) && (!TestData.propertyIdProperty.isEmpty())))) {
      int _parseInt = Integer.parseInt(TestData.propertyIdProperty);
      result.add(new Object[] { TestData.modelNameProperty, Integer.valueOf(_parseInt) });
    } else {
      Pair<String, Integer> _mappedTo = Pair.<String, Integer>of("benchmarking_model_x1_t10.xminijava", Integer.valueOf(25));
      Pair<String, Integer> _mappedTo_1 = Pair.<String, Integer>of("benchmarking_model_x10_t10.xminijava", Integer.valueOf(50));
      Pair<String, Integer> _mappedTo_2 = Pair.<String, Integer>of("benchmarking_model_x100_t10.xminijava", Integer.valueOf(75));
      Pair<String, Integer> _mappedTo_3 = Pair.<String, Integer>of("benchmarking_model_x1_t100.xminijava", Integer.valueOf(25));
      Pair<String, Integer> _mappedTo_4 = Pair.<String, Integer>of("benchmarking_model_x10_t100.xminijava", Integer.valueOf(50));
      Pair<String, Integer> _mappedTo_5 = Pair.<String, Integer>of("benchmarking_model_x100_t100.xminijava", Integer.valueOf(75));
      final List<Map<String, Integer>> names = Collections.<Map<String, Integer>>unmodifiableList(CollectionLiterals.<Map<String, Integer>>newArrayList(Collections.<String, Integer>unmodifiableMap(CollectionLiterals.<String, Integer>newHashMap(_mappedTo)), Collections.<String, Integer>unmodifiableMap(CollectionLiterals.<String, Integer>newHashMap(_mappedTo_1)), Collections.<String, Integer>unmodifiableMap(CollectionLiterals.<String, Integer>newHashMap(_mappedTo_2)), Collections.<String, Integer>unmodifiableMap(CollectionLiterals.<String, Integer>newHashMap(_mappedTo_3)), Collections.<String, Integer>unmodifiableMap(CollectionLiterals.<String, Integer>newHashMap(_mappedTo_4)), Collections.<String, Integer>unmodifiableMap(CollectionLiterals.<String, Integer>newHashMap(_mappedTo_5))));
      for (final Map<String, Integer> nameMap : names) {
        {
          final Function1<String, Boolean> _function = (String it) -> {
            return Boolean.valueOf(true);
          };
          final String name = IterableExtensions.<String>findFirst(nameMap.keySet(), _function);
          final Integer nbProperties = nameMap.get(name);
          result.add(new Object[] { name, Integer.valueOf((-2)) });
          result.add(new Object[] { name, Integer.valueOf((-1)) });
          IntegerRange _upTo = new IntegerRange(0, ((nbProperties).intValue() - 1));
          for (final Integer scenarioID : _upTo) {
            result.add(new Object[] { name, scenarioID });
          }
        }
      }
    }
    return result;
  }
}
