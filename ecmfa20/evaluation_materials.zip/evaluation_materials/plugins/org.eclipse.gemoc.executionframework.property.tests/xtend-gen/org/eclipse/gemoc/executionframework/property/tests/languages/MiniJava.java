package org.eclipse.gemoc.executionframework.property.tests.languages;

import org.eclipse.gemoc.executionframework.test.lib.ILanguageWrapper;

@SuppressWarnings("all")
public class MiniJava implements ILanguageWrapper {
  @Override
  public String getEntryPoint() {
    return "public static void org.tetrabox.minijava.xminijava.aspects.ProgramAspect.main(org.tetrabox.minijava.xminijava.miniJava.Program)";
  }
  
  @Override
  public String getLanguageName() {
    return "org.tetrabox.minijava.XMiniJava";
  }
  
  @Override
  public String getInitializationMethod() {
    return "org.tetrabox.minijava.xminijava.aspects.ProgramAspect.initialize";
  }
}
