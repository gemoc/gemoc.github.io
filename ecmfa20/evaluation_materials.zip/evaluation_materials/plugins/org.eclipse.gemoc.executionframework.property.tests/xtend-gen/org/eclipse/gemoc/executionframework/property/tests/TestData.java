package org.eclipse.gemoc.executionframework.property.tests;

import java.util.ArrayList;
import java.util.Collection;
import java.util.function.Consumer;
import org.eclipse.gemoc.executionframework.property.tests.ad.ActivityDiagramMonitoringTimeBenchmarkingTest;
import org.eclipse.gemoc.executionframework.property.tests.ad.ActivityDiagramTestData;

@SuppressWarnings("all")
public class TestData {
  protected final static String modelNameProperty = System.getProperty("modelNameProperty");
  
  protected final static String propertyIdProperty = System.getProperty("propertyIdProperty");
  
  public static Collection<Object[]> getData() {
    final ArrayList<Object[]> result = new ArrayList<Object[]>();
    final Consumer<Object[]> _function = (Object[] d) -> {
      String _name = ActivityDiagramMonitoringTimeBenchmarkingTest.class.getName();
      Object _get = d[0];
      Object _get_1 = d[1];
      result.add(new Object[] { _name, _get, _get_1 });
    };
    ActivityDiagramTestData.getData().forEach(_function);
    return result;
  }
}
