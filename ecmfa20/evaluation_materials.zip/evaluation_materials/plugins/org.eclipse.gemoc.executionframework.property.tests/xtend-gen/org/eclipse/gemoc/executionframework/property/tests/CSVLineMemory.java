package org.eclipse.gemoc.executionframework.property.tests;

import java.lang.reflect.Field;
import java.util.List;
import org.eclipse.gemoc.executionframework.property.tests.CSVLineTime;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.xbase.lib.CollectionLiterals;
import org.eclipse.xtext.xbase.lib.Conversions;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.IterableExtensions;

@SuppressWarnings("all")
public class CSVLineMemory {
  public String modelName = "";
  
  public int propertyID = (-1);
  
  public List<Long> memoryUsages = CollectionLiterals.<Long>newArrayList();
  
  private final static String separator = ";";
  
  private static Iterable<Field> getAllFields() {
    final Function1<Field, Boolean> _function = (Field f) -> {
      boolean _contentEquals = f.getName().contentEquals("separator");
      return Boolean.valueOf((!_contentEquals));
    };
    return IterableExtensions.<Field>filter(((Iterable<Field>)Conversions.doWrapArray(CSVLineTime.class.getDeclaredFields())), _function);
  }
  
  public static String getColumnNames() {
    final Function1<Field, String> _function = (Field f) -> {
      return f.getName();
    };
    final Iterable<String> allNames = IterableExtensions.<Field, String>map(CSVLineMemory.getAllFields(), _function);
    return IterableExtensions.join(allNames, CSVLineMemory.separator);
  }
  
  public String customToString() {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append(this.modelName);
    _builder.append(CSVLineMemory.separator);
    _builder.append(this.propertyID);
    _builder.append(CSVLineMemory.separator);
    {
      boolean _hasElements = false;
      for(final Long u : this.memoryUsages) {
        if (!_hasElements) {
          _hasElements = true;
        } else {
          _builder.appendImmediate(";", "");
        }
        _builder.append(u);
      }
    }
    return _builder.toString();
  }
}
