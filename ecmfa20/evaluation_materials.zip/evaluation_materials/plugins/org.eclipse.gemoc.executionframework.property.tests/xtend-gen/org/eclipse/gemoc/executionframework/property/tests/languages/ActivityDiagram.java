package org.eclipse.gemoc.executionframework.property.tests.languages;

import org.eclipse.gemoc.executionframework.test.lib.ILanguageWrapper;

@SuppressWarnings("all")
public class ActivityDiagram implements ILanguageWrapper {
  @Override
  public String getEntryPoint() {
    return "public static void org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityAspect.main(org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Activity)";
  }
  
  @Override
  public String getLanguageName() {
    return "org.eclipse.gemoc.activitydiagram.sequential.ActivityDiagram";
  }
  
  @Override
  public String getInitializationMethod() {
    return "org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityAspect.initializeModel";
  }
}
