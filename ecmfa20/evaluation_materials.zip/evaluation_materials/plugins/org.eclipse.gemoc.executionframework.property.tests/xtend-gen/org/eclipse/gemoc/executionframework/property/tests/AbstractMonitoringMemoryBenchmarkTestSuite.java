package org.eclipse.gemoc.executionframework.property.tests;

import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import org.eclipse.gemoc.execution.sequential.javaengine.tests.wrapper.JavaEngineWrapper;
import org.eclipse.gemoc.executionframework.property.monitor.manager.PropertyManager;
import org.eclipse.gemoc.executionframework.property.tests.AbstractMonitoringTestSuite;
import org.eclipse.gemoc.executionframework.property.tests.CSVLineMemory;
import org.eclipse.gemoc.executionframework.property.tests.Util;
import org.eclipse.gemoc.executionframework.test.lib.IEngineWrapper;
import org.eclipse.gemoc.executionframework.test.lib.IExecutableModel;
import org.eclipse.gemoc.executionframework.test.lib.ILanguageWrapper;
import org.eclipse.gemoc.executionframework.test.lib.impl.TestHelper;
import org.eclipse.gemoc.executionframework.test.lib.impl.TestModel;
import org.eclipse.gemoc.trace.commons.model.trace.Step;
import org.eclipse.gemoc.xdsmlframework.api.core.IExecutionEngine;
import org.eclipse.gemoc.xdsmlframework.api.engine_addon.IEngineAddon;
import org.eclipse.xtend.lib.annotations.Data;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.xbase.lib.CollectionLiterals;
import org.eclipse.xtext.xbase.lib.Exceptions;
import org.eclipse.xtext.xbase.lib.InputOutput;
import org.eclipse.xtext.xbase.lib.IntegerRange;
import org.eclipse.xtext.xbase.lib.ObjectExtensions;
import org.eclipse.xtext.xbase.lib.Procedures.Procedure1;
import org.eclipse.xtext.xbase.lib.Pure;
import org.eclipse.xtext.xbase.lib.util.ToStringBuilder;
import org.junit.AfterClass;
import org.junit.BeforeClass;

@SuppressWarnings("all")
public abstract class AbstractMonitoringMemoryBenchmarkTestSuite extends AbstractMonitoringTestSuite {
  @Data
  public static class BenchResult1 {
    private final List<List<Long>> allMemoryUsages;
    
    public BenchResult1(final List<List<Long>> allMemoryUsages) {
      super();
      this.allMemoryUsages = allMemoryUsages;
    }
    
    @Override
    @Pure
    public int hashCode() {
      return 31 * 1 + ((this.allMemoryUsages== null) ? 0 : this.allMemoryUsages.hashCode());
    }
    
    @Override
    @Pure
    public boolean equals(final Object obj) {
      if (this == obj)
        return true;
      if (obj == null)
        return false;
      if (getClass() != obj.getClass())
        return false;
      AbstractMonitoringMemoryBenchmarkTestSuite.BenchResult1 other = (AbstractMonitoringMemoryBenchmarkTestSuite.BenchResult1) obj;
      if (this.allMemoryUsages == null) {
        if (other.allMemoryUsages != null)
          return false;
      } else if (!this.allMemoryUsages.equals(other.allMemoryUsages))
        return false;
      return true;
    }
    
    @Override
    @Pure
    public String toString() {
      ToStringBuilder b = new ToStringBuilder(this);
      b.add("allMemoryUsages", this.allMemoryUsages);
      return b.toString();
    }
    
    @Pure
    public List<List<Long>> getAllMemoryUsages() {
      return this.allMemoryUsages;
    }
  }
  
  @Data
  public static class BenchResult2 {
    private final List<Long> memoryUsages;
    
    public BenchResult2(final List<Long> memoryUsages) {
      super();
      this.memoryUsages = memoryUsages;
    }
    
    @Override
    @Pure
    public int hashCode() {
      return 31 * 1 + ((this.memoryUsages== null) ? 0 : this.memoryUsages.hashCode());
    }
    
    @Override
    @Pure
    public boolean equals(final Object obj) {
      if (this == obj)
        return true;
      if (obj == null)
        return false;
      if (getClass() != obj.getClass())
        return false;
      AbstractMonitoringMemoryBenchmarkTestSuite.BenchResult2 other = (AbstractMonitoringMemoryBenchmarkTestSuite.BenchResult2) obj;
      if (this.memoryUsages == null) {
        if (other.memoryUsages != null)
          return false;
      } else if (!this.memoryUsages.equals(other.memoryUsages))
        return false;
      return true;
    }
    
    @Override
    @Pure
    public String toString() {
      ToStringBuilder b = new ToStringBuilder(this);
      b.add("memoryUsages", this.memoryUsages);
      return b.toString();
    }
    
    @Pure
    public List<Long> getMemoryUsages() {
      return this.memoryUsages;
    }
  }
  
  private static File outputFolder;
  
  private static File outputCSV;
  
  private static PrintWriter outputCSVWriter;
  
  private static FileOutputStream outputCSVStream;
  
  public abstract String getSemanticsPlugin();
  
  @BeforeClass
  public static void before() {
    try {
      final Calendar currentDate = Calendar.getInstance();
      final SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-YYYY_HH-mm-ss");
      final String dateNow = formatter.format(currentDate.getTime());
      File _file = new File((("output_time" + "_") + dateNow));
      AbstractMonitoringMemoryBenchmarkTestSuite.outputFolder = _file;
      boolean _exists = AbstractMonitoringMemoryBenchmarkTestSuite.outputFolder.exists();
      boolean _not = (!_exists);
      if (_not) {
        AbstractMonitoringMemoryBenchmarkTestSuite.outputFolder.mkdir();
      }
      File _file_1 = new File(AbstractMonitoringMemoryBenchmarkTestSuite.outputFolder, "resultsMemory.csv");
      AbstractMonitoringMemoryBenchmarkTestSuite.outputCSV = _file_1;
      FileOutputStream _fileOutputStream = new FileOutputStream(AbstractMonitoringMemoryBenchmarkTestSuite.outputCSV);
      AbstractMonitoringMemoryBenchmarkTestSuite.outputCSVStream = _fileOutputStream;
      PrintWriter _printWriter = new PrintWriter(AbstractMonitoringMemoryBenchmarkTestSuite.outputCSVStream, true);
      AbstractMonitoringMemoryBenchmarkTestSuite.outputCSVWriter = _printWriter;
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
  
  @AfterClass
  public static void after() {
    try {
      AbstractMonitoringMemoryBenchmarkTestSuite.outputCSVStream.close();
      AbstractMonitoringMemoryBenchmarkTestSuite.outputCSVWriter.close();
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
  
  public AbstractMonitoringMemoryBenchmarkTestSuite(final String model, final int scenarioID) {
    super(model, scenarioID);
  }
  
  public IEngineAddon getMemoryMonitoringAddon(final ArrayList<Long> memoryUsages) {
    return new IEngineAddon() {
      @Override
      public void stepExecuted(final IExecutionEngine<?> engine, final Step<?> stepExecuted) {
        final long m = Util.getCurrentlyUsedMemory();
        memoryUsages.add(Long.valueOf(m));
      }
      
      @Override
      public void aboutToExecuteStep(final IExecutionEngine<?> engine, final Step<?> stepToExecute) {
        final long m = Util.getCurrentlyUsedMemory();
        memoryUsages.add(Long.valueOf(m));
      }
    };
  }
  
  public AbstractMonitoringMemoryBenchmarkTestSuite.BenchResult1 runBench(final IEngineWrapper engine, final ILanguageWrapper language, final IExecutableModel model, final String propertyFilepath) {
    final ArrayList<List<Long>> allMemoryUsages = new ArrayList<List<Long>>();
    Set<IEngineAddon> _xifexpression = null;
    if (((propertyFilepath != null) && (!propertyFilepath.isEmpty()))) {
      Set<IEngineAddon> _xblockexpression = null;
      {
        final PropertyManager propertyManager = new PropertyManager();
        propertyManager.addProperty(propertyFilepath, true);
        _xblockexpression = Collections.<IEngineAddon>unmodifiableSet(CollectionLiterals.<IEngineAddon>newHashSet(propertyManager));
      }
      _xifexpression = _xblockexpression;
    } else {
      _xifexpression = Collections.<IEngineAddon>unmodifiableSet(CollectionLiterals.<IEngineAddon>newHashSet());
    }
    final Set<IEngineAddon> addons = _xifexpression;
    IntegerRange _upTo = new IntegerRange(1, 30);
    for (final Integer x : _upTo) {
      {
        final ArrayList<Long> memoryUsages = new ArrayList<Long>();
        allMemoryUsages.add(memoryUsages);
        HashSet<IEngineAddon> _newHashSet = CollectionLiterals.<IEngineAddon>newHashSet();
        final Procedure1<HashSet<IEngineAddon>> _function = (HashSet<IEngineAddon> it) -> {
          it.addAll(addons);
        };
        final Set<IEngineAddon> actualAddons = ObjectExtensions.<HashSet<IEngineAddon>>operator_doubleArrow(_newHashSet, _function);
        actualAddons.add(this.getMemoryMonitoringAddon(memoryUsages));
        TestHelper.testWithJob(engine, language, Collections.<String>unmodifiableSet(CollectionLiterals.<String>newHashSet()), actualAddons, model, true);
        Util.cleanup(this.getSemanticsPlugin());
      }
    }
    int _size = allMemoryUsages.size();
    int _minus = (_size - 11);
    List<List<Long>> _subList = allMemoryUsages.subList(_minus, allMemoryUsages.size());
    return new AbstractMonitoringMemoryBenchmarkTestSuite.BenchResult1(_subList);
  }
  
  public AbstractMonitoringMemoryBenchmarkTestSuite.BenchResult2 testGeneric(final String name, final IEngineWrapper engine, final ILanguageWrapper language, final String plugin, final String folder, final String model, final int propertyID) {
    final Optional<String> property = AbstractMonitoringTestSuite.findProperty(model, plugin, folder, propertyID);
    String _xifexpression = null;
    boolean _isPresent = property.isPresent();
    if (_isPresent) {
      _xifexpression = property.get();
    } else {
      _xifexpression = "";
    }
    final String propertyFilepath = _xifexpression;
    TestModel _testModel = new TestModel(plugin, folder, model, "", "");
    final AbstractMonitoringMemoryBenchmarkTestSuite.BenchResult1 result1 = this.runBench(engine, language, _testModel, propertyFilepath);
    final List<List<Long>> numbers = result1.allMemoryUsages;
    StringConcatenation _builder = new StringConcatenation();
    _builder.append(name);
    _builder.append(" - ");
    _builder.append(model);
    _builder.append(" - scenario ");
    _builder.append(propertyID);
    _builder.append(" :");
    InputOutput.<String>println(_builder.toString());
    List<Long> _listMedian = Util.getListMedian(numbers);
    String _plus = ("- median: " + _listMedian);
    InputOutput.<String>println(_plus);
    List<Long> _listMedian_1 = Util.getListMedian(numbers);
    return new AbstractMonitoringMemoryBenchmarkTestSuite.BenchResult2(_listMedian_1);
  }
  
  public abstract ILanguageWrapper getDSL();
  
  public AbstractMonitoringMemoryBenchmarkTestSuite.BenchResult2 testMonitoring(final String plugin, final String folder, final String model, final int propertyID) {
    final JavaEngineWrapper engine = new JavaEngineWrapper();
    return this.testGeneric("monitoring", engine, this.getDSL(), plugin, folder, model, propertyID);
  }
  
  @Override
  public void genericInternalTest(final String plugin, final String folder, final String model, final int propertyID) {
    final CSVLineMemory line = new CSVLineMemory();
    line.modelName = model;
    line.propertyID = propertyID;
    final AbstractMonitoringMemoryBenchmarkTestSuite.BenchResult2 resultMonitoring = this.testMonitoring(plugin, folder, model, propertyID);
    line.memoryUsages = resultMonitoring.memoryUsages;
    AbstractMonitoringMemoryBenchmarkTestSuite.outputCSVWriter.println(line.customToString());
  }
}
