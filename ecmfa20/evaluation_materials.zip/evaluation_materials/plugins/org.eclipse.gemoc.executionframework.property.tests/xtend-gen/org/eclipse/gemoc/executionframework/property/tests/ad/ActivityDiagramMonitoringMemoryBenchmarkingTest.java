package org.eclipse.gemoc.executionframework.property.tests.ad;

import java.util.Collection;
import org.eclipse.gemoc.executionframework.property.tests.AbstractMonitoringMemoryBenchmarkTestSuite;
import org.eclipse.gemoc.executionframework.property.tests.ad.ActivityDiagramTestData;
import org.eclipse.gemoc.executionframework.property.tests.languages.ActivityDiagram;
import org.eclipse.gemoc.executionframework.test.lib.ILanguageWrapper;
import org.junit.Ignore;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

@Ignore
@RunWith(Parameterized.class)
@SuppressWarnings("all")
public class ActivityDiagramMonitoringMemoryBenchmarkingTest extends AbstractMonitoringMemoryBenchmarkTestSuite {
  public ActivityDiagramMonitoringMemoryBenchmarkingTest(final String model, final int scenarioID) {
    super(model, scenarioID);
  }
  
  @Parameterized.Parameters(name = "{1}")
  public static Collection<Object[]> data() {
    return ActivityDiagramTestData.getData();
  }
  
  @Override
  public String getSemanticsPlugin() {
    return "org.eclipse.gemoc.activitydiagram.sequential.k3dsa";
  }
  
  @Override
  public ILanguageWrapper getDSL() {
    return new ActivityDiagram();
  }
  
  @Override
  public String getPluginName() {
    return "org.eclipse.gemoc.activitydiagram.sequential.property.benchmark";
  }
}
