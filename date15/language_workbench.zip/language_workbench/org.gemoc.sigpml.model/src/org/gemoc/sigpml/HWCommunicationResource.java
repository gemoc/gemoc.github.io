/**
 */
package org.gemoc.sigpml;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>HW Communication Resource</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.gemoc.sigpml.SigpmlPackage#getHWCommunicationResource()
 * @model
 * @generated
 */
public interface HWCommunicationResource extends HWRessource {
} // HWCommunicationResource
