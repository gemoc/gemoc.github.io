/**
 */
package org.gemoc.sigpml;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Output Port</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.gemoc.sigpml.SigpmlPackage#getOutputPort()
 * @model
 * @generated
 */
public interface OutputPort extends Port {
} // OutputPort
