/**
 */
package org.gemoc.sigpml.impl;

import org.eclipse.emf.ecore.EClass;

import org.gemoc.sigpml.HWCommunicationResource;
import org.gemoc.sigpml.SigpmlPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>HW Communication Resource</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class HWCommunicationResourceImpl extends HWRessourceImpl implements HWCommunicationResource {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected HWCommunicationResourceImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SigpmlPackage.Literals.HW_COMMUNICATION_RESOURCE;
	}

} //HWCommunicationResourceImpl
