/**
 */
package org.gemoc.sigpml;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Input Port</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.gemoc.sigpml.SigpmlPackage#getInputPort()
 * @model
 * @generated
 */
public interface InputPort extends Port {
} // InputPort
