#!/bin/sh


if test $# -ne 1
then
  echo "usage: ./processDotfile.sh sourceDotFile"
else
  ./ciprianize.sh $1 $1.cip &&
  ./extract_ASAP_schedule.sh $1 $1.asap.cip &&
  ./cleanUpDot.sh $1 $1.clean.dot &&
  sfdp -Tpng $1.clean.dot > $1.clean.png
fi