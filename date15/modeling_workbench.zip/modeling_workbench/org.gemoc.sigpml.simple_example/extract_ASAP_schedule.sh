#!/bin/sh


keepLonger(){
  longest=""
  maxSize=0
  while read line
  do
    lineSize=$(echo $line | sed -e 's/[^,]*,*/x/g' | wc -c)
    if test $lineSize -gt $maxSize
    then
      maxSize=$lineSize
      longest=$line
    fi
  done
  echo $longest
}
  

extract(){

  nextSource=0
  while read line
  do
    if echo $line | grep -q -e "^$nextSource ->"
    then
      longest=$(grep -e "^	$nextSource ->" $1 |keepLonger)
      nextSource=$(echo $longest | cut -d ' ' -f3)
      echo $longest |cut -d ' ' -f1,3
    fi
  done < $1
 }


if test $# -ne 2
then
  echo "usage: ./extractASAP_schedule sourceCipFile resCipFile"
else
  extract $1 >$2
fi